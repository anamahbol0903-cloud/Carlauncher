window.IBZ_CONFIG={"frames": 36, "homeView": 6, "lights": true, "car": {"name": "207", "model": "Peugeot 207"}};
