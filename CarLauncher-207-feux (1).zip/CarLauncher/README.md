# Car Launcher — Peugeot 207

Lanceur Android pour l'écran de la 207 (version allégée du Car Launcher 1.27.1).

## Ce qu'il contient
- Accueil avec la **207 en 3D** (36 vues pré-rendues, on la fait tourner au doigt), musique, radio, applis, horloge.
- **Compteur de vitesse** (lu sur le CAN, sinon sur le GPS), température extérieure, eau, huile, batterie.
- Page **Véhicule** = ordinateur de bord (autonomie, consommation, carburant, kilométrage…), lu sur l'appli CAN de l'autoradio.
- **Personnaliser** : fond d'écran, couleur de l'interface, thème, icônes perso.

## Ce qui a été retiré
Entretien (carnet, révision, vidange, PDF), radars de recul, détection et animation des portes, alertes
« ouvrant ouvert en roulant », fenêtre flottante, packs voiture, assistant d'apprentissage des portes,
exports QR / rapports, outils de rendu, documentation et historique des versions.

## Construire l'APK
Ouvrir le dossier dans Android Studio, puis Build > Build APK (ou `./gradlew assembleDebug`).
Même identifiant d'appli que l'ancienne version (`fr.ibiza.launcher`) : elle se met à jour par-dessus.

## Changer les images de la voiture
Les vues sont dans `app/src/main/assets/www/img/car/` : `hero_00.webp` … `hero_35.webp` (une tous les 10°, la vue 6 = 3/4
avant droit) et `floor.webp` (le plateau). `www/js/config.js` donne le nombre de vues (`frames`) et la vue de départ (`homeView`).

## Crédits
Modèle 3D « Peugeot 207 » par **romanian_guy_0069** (https://sketchfab.com/3d-models/peugeot-207-3d849c22f2914013a183484a57fa71ba),
licence **CC BY 4.0** (https://creativecommons.org/licenses/by/4.0/). Modifications : rendu en images 2D (36 vues + plateau)
et plaque d'immatriculation effacée. Cette mention doit rester si tu partages l'application.

## Feux (halo des phares)

Quand les feux de position ou de croisement sont allumés, la 207 3D s'éclaire (phares + feux arrière), avec un fondu.
Signal : réglage Android `Settings.System / carletter_night_mode` (0 = éteint, 1 = allumé) sur l'autoradio RK3326
(`auto_rk_t10`), lu par `Hub.java` (au démarrage puis toutes les secondes). Les halos sont dans `img/car/lights_00..35.webp`
(un par vue, même rotation que `hero_XX.webp`) ; `"lights": true` dans `js/config.js` les active. Le thème passe aussi en sombre.
