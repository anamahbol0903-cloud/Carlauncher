/* Pont vers l'app Android (window.Native). Hors Android : données de démo. */
(function () {
  var N = window.Native || null;
  var listeners = {};
  function on(type, fn) { (listeners[type] = listeners[type] || []).push(fn); }
  function emit(type, data) { (listeners[type] || []).forEach(function (f) { try { f(data); } catch (e) { console.error(e); } }); }
  /* appelé par Android : window.onNative('media', '{...}') */
  window.onNative = function (type, json) {
    var d = json; try { if (typeof json === 'string') d = JSON.parse(json); } catch (e) {}
    emit(type, d);
  };
  function parse(s, dflt) { try { return JSON.parse(s); } catch (e) { return dflt; } }

  var mock = !N;
  var demoApps = [
    ['com.ex.navi', 'Navigation'], ['com.ex.music', 'Musique'], ['com.ex.bt', 'Bluetooth'], ['com.ex.zlink', 'CarPlay'],
    ['com.ex.radio', 'Radio'], ['com.ex.video', 'Vidéo'], ['com.android.settings', 'Paramètres'], ['com.ex.eq', 'Égaliseur'],
    ['com.ex.canbus', 'Voiture'], ['com.ex.files', 'Fichiers'], ['com.android.chrome', 'Chrome'], ['com.waze', 'Waze'],
    ['com.spotify.music', 'Spotify'], ['com.ex.aux', 'AUX'], ['com.ex.usb', 'USB'], ['com.ex.gallery', 'Galerie'],
    ['com.ex.calc', 'Calculatrice'], ['com.ex.clock', 'Horloge'], ['com.ex.weather', 'Météo'], ['com.ex.store', 'Play Store']
  ].map(function (a) { return { pkg: a[0], cls: a[0] + '.Main', label: a[1], icon: '' }; });

  var demo = {
    media: { playing: true, title: 'Midnight City', artist: 'M83', source: 'Bluetooth', pos: 72, dur: 243 },
    perms: { notif: false, access: false, overlay: false, home: false }
  };

  var demoCar = { oil: 92, coolant: 89, outside: 11, battery: 14.2, range: 520, cons: 5.8, avg: 47, odo: 84213, rpm: 830, src: 'démo' };
  /* v1.27 : démo de « Apprendre l'ordinateur de bord » (ce que renvoie Android après la capture d'une page) */
  var demoCanApp = { has: false, pkg: '', label: '', fields: 0, access: true, hcn: false, gestures: true };
  var demoCanLearn = { pkg: 'com.ex.canbus', label: 'Voiture', taps: 1, pages: [{ cands: [
    { i: 0, label: 'Voltage de batterie', value: '14.3', unit: 'V', key: 'battery' }, { i: 1, label: 'Huile résiduelle', value: '38', unit: 'L', key: 'fuel' },
    { i: 2, label: 'Kilométrage', value: '84213', unit: 'KM', key: 'odo' }, { i: 3, label: 'Temp. extérieure', value: '11.5', unit: '℃', key: 'outside' },
    { i: 4, label: 'La vitesse du moteur', value: '831', unit: 'RPM', key: 'rpm' }, { i: 5, label: 'Trip A', value: '12.4', unit: 'km', key: null },
    { i: 6, label: '', value: '3', unit: '', key: null }] }] };
  var API = {
    mock: mock,
    on: on,
    apps: function () {
      if (mock) return demoApps;
      var list = parse(N.getApps(), []);
      var v = Date.now();
      list.forEach(function (a) { a.icon = 'https://appassets.androidplatform.net/icons/' + encodeURIComponent(a.pkg) + '/' + encodeURIComponent(a.cls) + '.png?v=' + v; });
      return list;
    },
    launch: function (a) { if (mock) { API.toast('Ouverture : ' + a.label); return; } N.launch(a.pkg, a.cls); },
    state: function () { return mock ? demo : parse(N.getState(), demo); },
    media: function (cmd) {
      if (mock) {
        if (cmd === 'toggle') demo.media.playing = !demo.media.playing;
        if (cmd === 'next' || cmd === 'prev') demo.media.pos = 0;
        emit('media', demo.media); return;
      }
      N.media(cmd);
    },
    openAccess: function () { if (mock) { API.toast('Réglage système : access'); return 'opened'; } return N.openAccess ? N.openAccess() : (N.openSystem('access'), 'opened'); },
    accessHint: function () { return mock ? !!window.__a13 : (N.accessHint ? N.accessHint() : false); },   // v1.27 : Android 13+, « paramètre restreint »,
    accessCommand: function () { return mock || !N.accessCommand ? 'adb shell pm grant fr.ibiza.launcher android.permission.WRITE_SECURE_SETTINGS' : N.accessCommand(); },
    openSystem: function (which) { if (mock) { API.toast('Réglage système : ' + which); return; } N.openSystem(which); },
    setPref: function (k, v) { if (!mock && N.setPref) N.setPref(k, String(v)); },
    diag: function () { return mock ? 'Mode démo : pas de journal.' : N.getDiag(); },
    diagExport: function () { return mock ? '' : N.exportDiag(); },
    diagClear: function () { if (!mock) N.clearDiag(); },
    toast: function (t) { emit('toast', t); },
    iconDir: function () { return mock ? '/sdcard/Android/data/fr.ibiza.launcher/files/icons' : N.iconDir(); },
    reloadIcons: function () { if (mock) emit('apps', {}); else N.reloadIcons(); },
    appList: function () { return mock ? '/sdcard/Android/data/fr.ibiza.launcher/files/icons/_liste_des_applis.txt' : (N.exportAppList ? N.exportAppList() : ''); },
    canUninstall: function (pkg) { return mock ? true : (N.canUninstall ? N.canUninstall(pkg) : false); },
    uninstall: function (pkg) { if (mock) { API.toast('Désinstallation (démo) : ' + pkg); return true; } return N.uninstall ? N.uninstall(pkg) : false; },
    launchPkg: function (pkg) { if (mock) { API.toast('Ouverture : ' + pkg); return; } if (N.launchPkg) N.launchPkg(pkg); },
    canLogs: function () { return mock ? false : (N.canLogs ? N.canLogs() : false); },
    canLive: function () { return mock ? false : (N.canLive ? N.canLive() : false); },
    canRefresh: function () { if (mock) { API.toast('Lecture CarCan (démo)'); return; } if (N.canRefresh) N.canRefresh(); },
    canRefreshPossible: function () { return mock ? true : (N.canRefreshPossible ? N.canRefreshPossible() : false); },
    car: function () { return mock ? demoCar : parse(N.getCar ? N.getCar() : '{}', {}); },
    /* mode apprentissage : l'état du poste est lu avant puis après une action dans la voiture, la différence est renvoyée */
    learnBegin: function () { if (!mock && N.learnBegin) N.learnBegin(); },
    learnEnd: function (step) {
      if (mock || !N.learnEnd) {                       // démo : ce que renverrait un poste réel
        if (step === 'lights_on') return { changes: [{ k: 'system/carletter_night_mode', from: '0', to: '1' }], events: [] };
        if (step === 'lights_off') return { changes: [{ k: 'system/carletter_night_mode', from: '1', to: '0' }], events: [] };
        if (step.indexOf('door_open') === 0) return { changes: [], events: ['com.clw.vehicleinfos / android.widget.RelativeLayout ×2'] };
        return { changes: [], events: [] };
      }
      return parse(N.learnEnd(), { changes: [], events: [] });
    },
    setLightsKey: function (k, on) { if (!mock && N.setLightsKey) N.setLightsKey(k, on); },
    lightsKey: function () { return mock ? 'system/carletter_night_mode|1' : (N.getLightsKey ? N.getLightsKey() : ''); },
    lightsState: function () { return mock ? { on: false } : parse(N.lightsState ? N.lightsState() : '{}', {}); }
  };
  if (mock) {
    setTimeout(function () { emit('car', demoCar); }, 300);
    setInterval(function () {
      if (demo.media.playing) { demo.media.pos = (demo.media.pos + 1) % demo.media.dur; emit('media', demo.media); }
    }, 1000);
  }
  window.Bridge = API;
})();
