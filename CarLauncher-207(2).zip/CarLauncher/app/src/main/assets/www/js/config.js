window.IBZ_CONFIG={"frames": 72, "homeView": 12, "car": {"name": "207", "model": "Peugeot 207"}};
