(function () {
  'use strict';
  var $ = function (s, r) { return (r || document).querySelector(s); };
  var $$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };
  var svg = Icons.svg, Spring = Motion.Spring;
  var store = {
    get: function (k, d) { try { var v = localStorage.getItem('ibz.' + k); return v == null ? d : JSON.parse(v); } catch (e) { return d; } },
    set: function (k, v) { try { localStorage.setItem('ibz.' + k, JSON.stringify(v)); } catch (e) {} Bridge.setPref(k, JSON.stringify(v)); }
  };
  var CFG = window.IBZ_CONFIG || { frames: 48, topBox: null };

  /* ======================= matériau verre ======================= */
  var root = document.documentElement;
  var lite = false;
  function applyLite() { lite = !!store.get('lite', false); root.classList.toggle('lite', lite); if (typeof drawAngle === 'function' && typeof angle !== 'undefined' && angle) { drawn.i = -1; drawAngle(angle.x); } }
  /* Mise à l'échelle : maquette pensée en 1024×600, adaptée à toute taille d'écran */
  var SC = 1, VW = 1024, VH = 600, PER_PAGE = 18;
  /* Taille de l'interface : 1 = maquette d'origine ; 1,12 « Grand » (défaut v1.5) ; 1,25 « Très grand » */
  var ZOOMS = { normal: 1, grand: 1.12, xl: 1.25 };
  function fit() {
    var w = window.innerWidth, h = window.innerHeight, portrait = h > w * 1.05;
    var Z = ZOOMS[store.get('zoom', 'grand')] || 1.12;
    if (portrait) { SC = w / (600 / Z); }
    else { SC = Math.max(0.6, h / (600 / Z)); if (w / SC < 860) SC = w / 860; }
    VW = Math.round(w / SC); VH = Math.round(h / SC);
    var app = $('#app'); app.style.width = VW + 'px'; app.style.height = VH + 'px'; app.style.transform = 'scale(' + SC + ')';
    root.classList.toggle('portrait', portrait);
    root.classList.toggle('wide', !portrait && VW > 1400);
    // v1.20 : bibliothèque d'apps sur 2 lignes (icônes plus grandes, par défaut) ou 3 lignes (d'origine)
    var big = store.get('appsRows', 2) === 2;
    root.classList.toggle('apps2', big && !portrait);
    PER_PAGE = portrait ? 20 : big ? (VW > 1400 ? 12 : 10) : (VW > 1400 ? 24 : 18);
  }
  function alignGlass() {
    root.style.setProperty('--vw', VW + 'px');
    root.style.setProperty('--vh', VH + 'px');
    $$('.glass').forEach(function (el) {
      var r = el.getBoundingClientRect();
      el.style.setProperty('--gx', (-r.left / SC) + 'px');
      el.style.setProperty('--gy', (-r.top / SC) + 'px');
    });
  }
  function applyGlassMode() {
    var m = store.get('glass', 'sim');
    document.body.classList.toggle('real-blur', m === 'real');
    document.body.classList.toggle('no-glass', m === 'off');
  }

  /* ======================= thème (sombre / clair / auto) ======================= */
  var isLight = false, sig = { lights: null, night: null };
  function applyTheme() {
    var t = store.get('theme', 'auto'), light;
    if (t === 'light') light = true;
    else if (t === 'dark') light = false;
    else if (sig.lights !== null) light = !sig.lights;          // phares allumés -> sombre
    else if (sig.night !== null) light = !sig.night;            // mode nuit Android
    else { var h = new Date().getHours(); light = h >= 7 && h < 20; }
    if (light === isLight && document.documentElement.classList.contains('themed')) return;
    isLight = light;
    root.classList.add('themed'); root.classList.toggle('light', light);
    wallNow = ''; applyWall();
  }
  Bridge.on('night', function (d) { sig.night = !!(d && d.night); applyTheme(); });
  Bridge.on('lights', function (d) { sig.lights = !!(d && d.on); applyTheme(); });

  /* ======================= fond d'écran ======================= */
  var WALLS = [['match', 'Suit le thème'], ['dark', 'Sombre'], ['light', 'Clair'], ['day', 'Jour'], ['evening', 'Soir'], ['sunset', 'Couchant'], ['night', 'Nuit']];
  function wallFor(sel) {
    if (sel === 'match') return isLight ? 'light' : 'dark';
    if (sel === 'auto') { var h = new Date().getHours(); return h >= 7 && h < 17 ? 'day' : h >= 17 && h < 19 ? 'evening' : h >= 19 && h < 21 ? 'sunset' : 'night'; }
    return sel;
  }
  var wallNow = '';
  function abs(u) { try { return new URL(u, location.href).href; } catch (e) { return u; } }
  function applyWall() {
    var sel = store.get('wall', 'match'), w = wallFor(sel), a, b;
    if (sel === 'custom') {
      try { a = localStorage.getItem('ibz.wallimg'); b = localStorage.getItem('ibz.wallblur'); } catch (e) {}
      if (!a) { sel = 'dark'; w = 'dark'; }
    }
    var key = sel === 'custom' ? 'custom' : w;
    if (key === wallNow) return; wallNow = key;
    measureWall(key === 'custom' ? b : abs('img/walls/' + w + '_t.jpg'));
    if (key === 'custom') { a = 'url(' + a + ')'; b = 'url(' + b + ')'; }
    else { a = 'url(' + abs('img/walls/' + w + '.jpg') + ')'; b = 'url(' + abs('img/walls/' + w + '_blur.jpg') + ')'; }
    root.style.setProperty('--wall', a); root.style.setProperty('--wall-blur', b);
  }
  /* fond clair (gris, blanc) -> libellés d'apps et points de page en sombre */
  function measureWall(url) {
    var im = new Image();
    im.onload = function () {
      try {
        var c = document.createElement('canvas'); c.width = 24; c.height = 14;
        var x = c.getContext('2d'); x.drawImage(im, 0, 0, 24, 14);
        var d = x.getImageData(0, 0, 24, 14).data, s = 0;
        for (var i = 0; i < d.length; i += 4) s += 0.2126 * d[i] + 0.7152 * d[i + 1] + 0.0722 * d[i + 2];
        root.classList.toggle('wall-bright', s / (d.length / 4) > 125);
      } catch (e) { root.classList.remove('wall-bright'); }
    };
    im.src = url;
  }
  function wallSheet() {
    var sel = store.get('wall', 'match');
    var h = WALLS.map(function (w) { var th = w[0] === 'match' ? 'dark' : w[0]; return '<div class="wthumb press' + (sel === w[0] ? ' on' : '') + '" data-w="' + w[0] + '" style="background-image:' + (w[0] === 'match' ? 'linear-gradient(90deg,rgba(0,0,0,0) 50%,rgba(255,255,255,.0) 50%),url(img/walls/light_t.jpg),url(img/walls/dark_t.jpg)' : 'url(img/walls/' + th + '_t.jpg)') + ';background-size:50% 100%,50% 100%,cover;background-position:0 0,100% 0,0 0;background-repeat:no-repeat"><span>' + w[1] + '</span></div>'; }).join('');
    h += '<div class="wthumb auto press' + (sel === 'auto' ? ' on' : '') + '" data-w="auto"><span>Selon l\'heure</span></div>';
    h += '<div class="wthumb usb press' + (sel === 'custom' ? ' on' : '') + '" data-w="usb">' + svg('files') + '<span>Clé USB…</span></div>';
    openSheet('<div class="t-headline">Fond d\'écran</div><div class="t-sub">« Selon l\'heure » passe du jour à la nuit tout seul.</div><div class="walls">' + h + '</div>', function (s) {
      $$('[data-w]', s).forEach(function (el) {
        tappable(el, function () {
          var w = el.getAttribute('data-w');
          if (w === 'usb') { closeSheet(); $('#wall-file').click(); return; }
          store.set('wall', w); applyWall(); closeSheet(); if (current === 'settings') renderSettings();
        });
      });
    });
  }
  /* v1.20 : disposition de l'accueil (Réglages). Les mêmes cartes sont seulement replacées par le CSS : aucune carte en
     plus en mémoire. « Voiture » = d'origine ; « Voiture XL » = voiture en grand, fine barre en bas ; « Conduite » =
     vitesse et ordinateur de bord en grand, voiture à droite, barre musique en bas. */
  var LAYOUTS = [
    ['car', 'Voiture', 'La voiture, la musique, l\'heure et les raccourcis.'],
    ['xl', 'Voiture XL', 'La voiture en grand, une fine barre en bas.'],
    ['drive', 'Conduite', 'Vitesse et ordinateur de bord en grand.']
  ];
  function layoutName() { var l = store.get('layout', 'car'); for (var i = 0; i < LAYOUTS.length; i++) if (LAYOUTS[i][0] === l) return LAYOUTS[i][1]; return LAYOUTS[0][1]; }
  function applyLayout(animate) {
    var l = store.get('layout', 'car');
    root.classList.toggle('lay-xl', l === 'xl');
    root.classList.toggle('lay-drive', l === 'drive');
    var g = $('.home-grid');
    if (animate && g && !lite && !(window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches)) {
      g.classList.remove('lay-in'); void g.offsetWidth; g.classList.add('lay-in');
    }
    drawn.i = -1; if (typeof angle !== 'undefined' && angle) drawAngle(angle.x);
    alignGlass();
    setTimeout(refitFrames, 400);        // après la mise en place : redécode les vues à la nouvelle taille si besoin
  }
  function layoutSheet() {
    var sel = store.get('layout', 'car');
    var h = LAYOUTS.map(function (L) {
      return '<button class="lthumb press' + (sel === L[0] ? ' on' : '') + '" data-l="' + L[0] + '">' +
        '<span class="lmini lm-' + L[0] + '"><i class="m-rail"></i><i class="m-car"></i><i class="m-a"></i><i class="m-b"></i><i class="m-c"></i></span>' +
        '<b>' + L[1] + '</b><small>' + L[2] + '</small></button>';
    }).join('');
    openSheet('<div class="t-headline">Disposition de l\'accueil</div><div class="t-sub">Les mêmes cartes, placées autrement.</div><div class="layouts">' + h + '</div>', function (s) {
      $$('[data-l]', s).forEach(function (el) {
        tappable(el, function () {
          var l = el.getAttribute('data-l');
          $$('[data-l]', s).forEach(function (o) { o.classList.toggle('on', o === el); });
          store.set('layout', l); closeSheet();
          if (current !== 'home') showPage('home');
          setTimeout(function () { applyLayout(true); if (current === 'settings') renderSettings(); }, 120);
        });
      });
    });
  }
  function loadCustomWall(file) {
    var rd = new FileReader();
    rd.onload = function () {
      var img = new Image();
      img.onload = function () {
        var W = 1024, H = 600, c = document.createElement('canvas'); c.width = W; c.height = H;
        var x = c.getContext('2d'), sc = Math.max(W / img.width, H / img.height), w = img.width * sc, h = img.height * sc;
        x.drawImage(img, (W - w) / 2, (H - h) / 2, w, h);
        var full = c.toDataURL('image/jpeg', 0.86);
        var b = document.createElement('canvas'); b.width = W; b.height = H; var bx = b.getContext('2d');
        if ('filter' in bx) { bx.filter = 'blur(28px)'; bx.drawImage(c, -40, -40, W + 80, H + 80); }
        else { var t = document.createElement('canvas'); t.width = 48; t.height = 28; t.getContext('2d').drawImage(c, 0, 0, 48, 28); bx.imageSmoothingEnabled = true; bx.drawImage(t, 0, 0, W, H); }
        try { localStorage.setItem('ibz.wallimg', full); localStorage.setItem('ibz.wallblur', b.toDataURL('image/jpeg', 0.8)); }
        catch (e) { toast('Image trop lourde'); return; }
        store.set('wall', 'custom'); wallNow = ''; applyWall(); toast('Fond d\'écran appliqué'); if (current === 'custom') renderCustom();
      };
      img.src = rd.result;
    };
    rd.readAsDataURL(file);
  }

  /* ======================= appui instantané ======================= */
  document.addEventListener('pointerdown', function (e) {
    var p = e.target.closest ? e.target.closest('.press, .press-soft, .app, .dock-slot, .row.btn, .qbtn') : null;
    if (!p) return;
    p.classList.add('down');
    var up = function () { p.classList.remove('down'); document.removeEventListener('pointerup', up); document.removeEventListener('pointercancel', up); };
    document.addEventListener('pointerup', up); document.addEventListener('pointercancel', up);
  }, true);

  /* tap = appui puis relâche sans déplacement (> 10 px annule) ; appui long = 550 ms */
  function tappable(el, onTap, onLong) {
    var sx, sy, t, moved, longFired, down = false;
    el.addEventListener('pointerdown', function (e) {
      sx = e.clientX; sy = e.clientY; moved = false; longFired = false; down = true;
      clearTimeout(t);
      if (onLong) t = setTimeout(function () { if (!moved) { longFired = true; el.classList.remove('down'); onLong(e); } }, 550);
    });
    el.addEventListener('pointermove', function (e) {
      if (Math.abs(e.clientX - sx) > 10 || Math.abs(e.clientY - sy) > 10) { moved = true; clearTimeout(t); }
    });
    el.addEventListener('pointerup', function (e) { clearTimeout(t); var ok = down && !moved && !longFired; down = false; if (ok) onTap(e); });
    el.addEventListener('pointercancel', function () { clearTimeout(t); moved = true; down = false; });
    el.addEventListener('pointerleave', function () { down = false; clearTimeout(t); });
  }

  /* ======================= horloge ======================= */
  var JOURS = ['dimanche', 'lundi', 'mardi', 'mercredi', 'jeudi', 'vendredi', 'samedi'];
  var MOIS = ['janvier', 'février', 'mars', 'avril', 'mai', 'juin', 'juillet', 'août', 'septembre', 'octobre', 'novembre', 'décembre'];
  var JOURS_C = ['dim.', 'lun.', 'mar.', 'mer.', 'jeu.', 'ven.', 'sam.'];
  var MOIS_C = ['janv.', 'févr.', 'mars', 'avr.', 'mai', 'juin', 'juil.', 'août', 'sept.', 'oct.', 'nov.', 'déc.'];
  /* v1.21 : aucun texte ne déborde de sa boîte, sans faire ramer le poste.
     (La 1.20 remesurait tous les textes à chaque changement de l'accueil, donc chaque seconde avec la musique, en forçant des
     dizaines de recalculs de mise en page : sur l'autoradio, l'interface ramait.)
     Maintenant : seuls les textes ajustables dont le contenu ou la place a changé sont mesurés ; toutes les mesures d'abord,
     puis toutes les écritures (un seul recalcul de mise en page) ; la bonne taille est calculée d'un coup, sans boucle.
     Tout est remesuré seulement si la disposition, la taille d'interface, le thème ou l'écran changent. */
  var FIT = [['#c-time', 0.6], ['.cd b', 0.68], ['.cd span', 0.8], ['.qbtn span', 0.72],
             ['.app-l', 0.76], ['#car-status span', 0.8], ['#m-title', 0.74, true]];
  var FIT_WATCH = '#quick, #apps-track, .cd-grid, .cd-main, #car-status, #m-title';
  var fitEpoch = 1, fitDone = 0, fitQueued = false, dateShort = false;
  function dateText(d, short) { return short ? JOURS_C[d.getDay()] + ' ' + d.getDate() + ' ' + MOIS_C[d.getMonth()] : JOURS[d.getDay()] + ' ' + d.getDate() + ' ' + MOIS[d.getMonth()]; }
  function fitTexts(all) {
    if (all === true) fitEpoch++;
    if (fitQueued) return; fitQueued = true;
    requestAnimationFrame(runFit);
  }
  function runFit() {
    fitQueued = false;
    var compact = root.classList.contains('lay-xl') || root.classList.contains('lay-drive'), fresh = fitDone !== fitEpoch, d = new Date();
    var items = [];
    FIT.forEach(function (f) { $$(f[0]).forEach(function (el) { items.push([el, f[1], !!f[2]]); }); });
    var dt = $('#c-date');
    // 0. écritures préalables, seulement quand tout doit être remesuré
    if (fresh) {
      items.forEach(function (it) { if (it[0].style.fontSize) it[0].style.fontSize = ''; it[0]._fs0 = null; it[0]._fitKey = null; });
      if (dt) dt.textContent = dateText(d, false);
    }
    // 1. lectures (un seul recalcul de mise en page pour toutes)
    var jobs = [], again = false;
    items.forEach(function (it) {
      var el = it[0];
      if (it[2] && !compact) { if (el.style.fontSize) jobs.push([el, '']); return; }
      var w = el.clientWidth; if (!w) return;
      var key = el.textContent + '|' + w;
      if (el._fitKey === key) return;
      if (el._fs0 == null) el._fs0 = parseFloat(getComputedStyle(el).fontSize) || 14;
      var fs0 = el._fs0, cur = parseFloat(el.style.fontSize) || fs0, need = el.scrollWidth * fs0 / cur;   // largeur à la taille d'origine
      var min = Math.max(10, fs0 * it[1]);
      var t = need <= w ? fs0 : Math.max(min, Math.floor(fs0 * (w - 1) / need * 4) / 4);
      if (need * t / fs0 > w && /^Dans /.test(el.textContent)) { jobs.push([el, null, el.textContent.replace(/^Dans /, '')]); again = true; return; }   // puce Entretien
      jobs.push([el, t >= fs0 ? '' : t + 'px']);
      el._fitKey = key;
    });
    if (dt && dt.clientWidth && fresh) dateShort = dt.scrollWidth > dt.clientWidth;
    // 2. écritures
    jobs.forEach(function (j) {
      if (j[1] === null) { j[0].textContent = j[2]; j[0]._fitKey = null; return; }
      if (j[0].style.fontSize !== j[1]) j[0].style.fontSize = j[1];
    });
    if (dt && fresh && dateShort) dt.textContent = dateText(d, true);
    fitDone = fitEpoch;
    if (again) fitTexts();                 // texte raccourci : remesuré au prochain passage
  }
  function pad(n) { return (n < 10 ? '0' : '') + n; }
  function setText(sel, v) { var el = $(sel); if (el && el.textContent !== v) el.textContent = v; }
  function tick() {
    var d = new Date(), t = pad(d.getHours()) + ':' + pad(d.getMinutes());
    setText('#rail-time', t); setText('#c-time', t);
    var dtxt = dateText(d, dateShort), cdt = $('#c-date'); if (cdt.textContent !== dtxt) cdt.textContent = dtxt;   // v1.21 : forme choisie par l'ajustement
  }

  /* ======================= apps & dock ======================= */
  var apps = [], appByKey = {};
  var VIRTUAL = [
    { pkg: ':vehicle', cls: '', label: 'Véhicule', theme: 'car', virtual: 'vehicle' },
    { pkg: ':settings', cls: '', label: 'Réglages lanceur', theme: 'launcher', virtual: 'settings' }
  ];
  function key(a) { return a.pkg + '/' + a.cls; }
  function loadApps() {
    var list = Bridge.apps() || [];
    list.forEach(function (a) { a.theme = a.custom ? null : Icons.themeFor(a); });
    list.sort(function (a, b) { return a.label.localeCompare(b.label, 'fr'); });
    apps = VIRTUAL.concat(list);
    appByKey = {}; apps.forEach(function (a) { appByKey[key(a)] = a; });
  }
  function openApp(a, originEl) {
    if (a.virtual) { showPage(a.virtual, originEl); return; }
    Bridge.launch(a);
  }
  function defaultDock() {
    var want = ['nav', 'music', 'phone', 'link'], out = [];
    want.forEach(function (th) {
      var f = null;
      var ra = roleApp(th); if (ra && out.indexOf(key(ra)) < 0) f = ra;
      if (!f) for (var i = 0; i < apps.length; i++) if (apps[i].theme === th && !apps[i].virtual && out.indexOf(key(apps[i])) < 0) { f = apps[i]; break; }
      out.push(f ? key(f) : null);
    });
    return out;
  }
  function renderDock() {
    var dock = store.get('dock', null);
    if (!dock || dock.length !== 4) { dock = defaultDock(); store.set('dock', dock); }
    if (!store.get('dockfix15', false)) { // v1.5 : le gestionnaire de fichiers avait été pris pour la musique
      var mus = findTheme('music');
      dock = dock.map(function (k) { var a = k && appByKey[k]; return a && a.theme === 'files' && mus ? key(mus) : k; });
      store.set('dock', dock); store.set('dockfix15', true);
    }
    var el = $('#dock'); el.innerHTML = '';
    dock.forEach(function (k, i) {
      var a = k ? appByKey[k] : null;
      var slot = document.createElement('div'); slot.className = 'dock-slot press';
      slot.innerHTML = a ? Icons.appIcon(a, 60) : '<div class="dock-empty">' + svg('plus') + '</div>';
      tappable(slot, function () { if (a) openApp(a, slot); else { showPage('apps', $('#btn-pages')); toast('Appui long sur une app pour la mettre dans le dock'); } },
        function () { dockSheet(i); });
      el.appendChild(slot);
    });
  }
  function setDock(i, a) { var d = store.get('dock', defaultDock()); d[i] = a ? key(a) : null; store.set('dock', d); renderDock(); alignGlass(); }

  /* ======================= feuilles (menus) ======================= */
  var sheetSpring = new Spring(0, { onUpdate: function (v) {
    var s = $('#sheet'); s.style.opacity = Math.max(0, Math.min(1, v));
    s.style.transform = 'translateY(-50%) scale(' + (0.92 + 0.08 * v) + ')';
    s.style.visibility = v > 0.01 ? 'visible' : 'hidden';
  } });
  function openSheet(html, bind) {
    var s = $('#sheet'); s.classList.remove('sheet-ready'); s.classList.remove('sheet-qr'); s.classList.remove('sheet-help'); s.classList.remove('sheet-acc'); s.classList.remove('sheet-learn'); s.removeAttribute('data-lk'); s.innerHTML = html; if (bind) bind(s);
    $('#sheet-scrim').classList.add('on'); alignGlass();
    sheetSpring.to(1, { response: 0.32, damping: 1 });
  }
  function closeSheet() { if (typeof SU !== 'undefined' && SU) SU.open = false; $('#sheet').style.top = ''; if (document.activeElement && document.activeElement.blur) document.activeElement.blur(); $('#sheet-scrim').classList.remove('on'); sheetSpring.to(0, { response: 0.25, damping: 1 }); }
  $('#sheet-scrim').addEventListener('click', function () {
    if (typeof SU !== 'undefined' && SU && SU.open) store.set('setupDone', true);   // v1.26.1 : assistant fermé en touchant à côté = « Plus tard » (pas de retour à chaque démarrage)
    closeSheet();
  });
  function appSheet(a) {
    var btns = '';
    for (var i = 0; i < 4; i++) btns += '<button class="sbtn press" data-slot="' + i + '">Dock · place ' + (i + 1) + '</button>';
    openSheet('<div class="t-headline">' + esc(a.label) + '</div><div class="t-sub">Choisis où l\'épingler dans la barre latérale.</div>' +
      '<div class="t-cap" style="margin-top:6px">Icône perso : icons/' + esc(a.pkg) + '.png</div>' +
      '<div class="sheet-actions">' + btns + '<button class="sbtn wide press" data-open="1">Ouvrir</button></div>', function (s) {
      $$('[data-slot]', s).forEach(function (b) { b.onclick = function () { setDock(+b.getAttribute('data-slot'), a); closeSheet(); toast('Ajouté au dock'); }; });
      $('[data-open]', s).onclick = function () { closeSheet(); openApp(a); };
    });
  }
  function dockSheet(i) {
    openSheet('<div class="t-headline">Place ' + (i + 1) + ' du dock</div><div class="t-sub">Pour changer d\'app : appui long sur une app dans la bibliothèque.</div>' +
      '<div class="sheet-actions"><button class="sbtn press" data-lib="1">Bibliothèque</button><button class="sbtn danger press" data-clear="1">Retirer</button></div>', function (s) {
      $('[data-lib]', s).onclick = function () { closeSheet(); showPage('apps', $('#btn-pages')); };
      $('[data-clear]', s).onclick = function () { setDock(i, null); closeSheet(); };
    });
  }
  function esc(t) { return String(t).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }

  /* ======================= toast ======================= */
  var toastT;
  function toast(t) { var el = $('#toast'); el.textContent = t; alignGlass(); el.classList.add('on'); clearTimeout(toastT); toastT = setTimeout(function () { el.classList.remove('on'); }, 2400); }
  Bridge.on('toast', toast);

  /* ======================= navigation entre pages ======================= */
  var current = 'home';
  var pageSprings = {};
  function pageEl(n) { return $('#page-' + n); }
  function showPage(name, originEl) {
    if (name === current) return;
    var from = pageEl(current), to = pageEl(name);
    var st = $('#stage').getBoundingClientRect();
    var ox = '50%', oy = '50%';
    if (originEl) { var r = originEl.getBoundingClientRect(); ox = ((r.left + r.width / 2 - st.left) / SC) + 'px'; oy = ((r.top + r.height / 2 - st.top) / SC) + 'px'; }
    to.style.transformOrigin = ox + ' ' + oy; from.style.transformOrigin = ox + ' ' + oy;
    animatePage(from, 0, 1.04); animatePage(to, 1, 0.9);
    current = name;
    $('#btn-pages').innerHTML = svg(name === 'home' ? 'grid' : 'dash');
    if (name === 'vehicle') renderVehicle();
    if (name === 'settings') renderSettings();
    if (name === 'custom') renderCustom();
    if (name === 'apps') setAppsPage(appsPageIdx, 0, true);
  }
  function animatePage(el, target, startScale) {
    var id = el.id, sp = pageSprings[id];
    if (!sp) {
      sp = pageSprings[id] = new Spring(el.classList.contains('is-active') ? 1 : 0, { onUpdate: function (v, s) {
        var sc = s.dir ? (s.from + (1 - s.from) * v) : (1 + (s.from - 1) * (1 - v));
        el.style.opacity = Math.max(0, Math.min(1, v));
        el.style.transform = 'scale(' + sc + ')';
        el.style.visibility = v > 0.005 ? 'visible' : 'hidden';
        el.style.pointerEvents = v > 0.5 ? 'auto' : 'none';
      } });
    }
    sp.dir = target === 1; sp.from = startScale;
    el.classList.toggle('is-active', target === 1);
    el.classList.add('anim');
    if (lite) { sp.set(target); el.style.transform = ''; el.classList.remove('anim'); if (target === 1) alignGlass(); return; }
    sp.to(target, { response: 0.38, damping: 1, onRest: function () { el.classList.remove('anim'); if (target === 1) { el.style.transform = ''; alignGlass(); } } });
  }
  tappable($('#btn-pages'), function () { showPage(current === 'home' ? 'apps' : 'home', $('#btn-pages')); });

  /* ======================= bibliothèque (pages + élan) ======================= */
  var appsPageIdx = 0, appsPages = 1, trackX = new Spring(0, { onUpdate: function (v) { $('#apps-track').style.transform = 'translate3d(' + v + 'px,0,0)'; } });
  function renderApps() {
    var per = PER_PAGE, vp = $('#apps-viewport'), w = vp.clientWidth || 900;
    var list = apps; appsPages = Math.max(1, Math.ceil(list.length / per));
    var html = '';
    for (var p = 0; p < appsPages; p++) {
      html += '<div class="apps-page" style="width:' + w + 'px">';
      list.slice(p * per, p * per + per).forEach(function (a, i) {
        html += '<div class="app" data-i="' + (p * per + i) + '">' + Icons.appIcon(a, root.classList.contains('apps2') ? 112 : 76) + '<div class="app-l">' + esc(a.label) + '</div></div>';
      });
      html += '</div>';
    }
    $('#apps-track').innerHTML = html;
    $$('.app', $('#apps-track')).forEach(function (el) {
      var a = list[+el.getAttribute('data-i')];
      tappable(el, function () { if (!dragging) openApp(a, el); }, function () { if (!a.virtual) appSheet(a); });
    });
    var dots = ''; for (var d = 0; d < appsPages; d++) dots += '<i></i>';
    $('#apps-dots').innerHTML = appsPages > 1 ? dots : '';
    setAppsPage(Math.min(appsPageIdx, appsPages - 1), 0, true);
  }
  function setAppsPage(i, vel, instant) {
    appsPageIdx = i;
    var w = $('#apps-viewport').clientWidth;
    if (instant) trackX.set(-i * w); else trackX.to(-i * w, { response: 0.4, damping: vel ? 0.86 : 1, velocity: vel || 0 });
    $$('#apps-dots i').forEach(function (d, k) { d.classList.toggle('on', k === i); });
  }
  var dragging = false;
  (function () {
    var vp = $('#apps-viewport'), tr = new Motion.Tracker(), sx = 0, sy = 0, base = 0, locked = null, id = null;
    vp.addEventListener('pointerdown', function (e) { id = e.pointerId; sx = e.clientX; sy = e.clientY; base = trackX.x; trackX.stop(); locked = null; dragging = false; tr = new Motion.Tracker(); tr.add(e.clientX / SC, 0); });
    vp.addEventListener('pointermove', function (e) {
      if (e.pointerId !== id) return;
      var dx = (e.clientX - sx) / SC, dy = (e.clientY - sy) / SC;
      if (locked === null && (Math.abs(dx) > 10 || Math.abs(dy) > 10)) { locked = Math.abs(dx) > Math.abs(dy) ? 'x' : 'y'; if (locked === 'x') { dragging = true; try { vp.setPointerCapture(id); } catch (er) {} } }
      if (locked !== 'x') return;
      tr.add(e.clientX / SC, 0);
      var w = vp.clientWidth, min = -(appsPages - 1) * w, x = base + dx;
      if (x > 0) x = Motion.rubber(x, w); else if (x < min) x = min - Motion.rubber(min - x, w);
      trackX.set(x);
    });
    function end(e) {
      if (e.pointerId !== id) return; id = null;
      if (locked !== 'x') return;
      var w = vp.clientWidth, v = tr.velocity().x;
      var projected = trackX.x + Motion.project(v, 0.99);
      var i = Math.round(-projected / w); i = Math.max(appsPageIdx - 1, Math.min(appsPageIdx + 1, i)); i = Math.max(0, Math.min(appsPages - 1, i));
      setAppsPage(i, v);
      setTimeout(function () { dragging = false; }, 50);
    }
    vp.addEventListener('pointerup', end); vp.addEventListener('pointercancel', end);
  })();

  /* ======================= plateau tournant 3D (Peugeot 207) ======================= */
  /* 48 vues pré-rendues (une tous les 7,5°). Entre deux vues voisines, chaque pixel suit le mouvement réel de la voiture
     (champ de mouvement précalculé exactement depuis le modèle 3D : img/car/flow_XX.png, 240×134, 8 Ko chacun) et la carte
     graphique dessine la position intermédiaire : la rotation est continue, sans double image. Les vues passent dans des
     textures et leurs copies sont libérées. Sans WebGL : fondu enchaîné classique. */
  var N = CFG.frames, STEP = 360 / N, bitmaps = new Array(N);
  var ttCanvas = $('#tt-canvas');
  var drawn = { i: -1, j: -1, t: -1, f: -1 };
  var GLR = CFG.flowMax ? makeGL(ttCanvas) : null;
  var ttCtx = GLR ? null : ttCanvas.getContext('2d');
  function makeGL(cv) {
    var gl = null, o = { alpha: true, premultipliedAlpha: true, antialias: false, depth: false, stencil: false, preserveDrawingBuffer: false, powerPreference: 'low-power' };
    try { gl = cv.getContext('webgl', o) || cv.getContext('experimental-webgl', o); } catch (e) { gl = null; }
    if (!gl) return null;
    function sh(type, src) { var x = gl.createShader(type); gl.shaderSource(x, src); gl.compileShader(x); return gl.getShaderParameter(x, gl.COMPILE_STATUS) ? x : null; }
    var vs = sh(gl.VERTEX_SHADER, 'attribute vec2 p; varying vec2 uv; void main(){ uv = vec2(p.x * 0.5 + 0.5, 0.5 - p.y * 0.5); gl_Position = vec4(p, 0.0, 1.0); }');
    var fs = sh(gl.FRAGMENT_SHADER, '#ifdef GL_FRAGMENT_PRECISION_HIGH\nprecision highp float;\n#else\nprecision mediump float;\n#endif\n' +
      'uniform sampler2D A; uniform sampler2D B; uniform sampler2D F; uniform float t; uniform vec2 k; varying vec2 uv;\n' +
      'void main(){ vec2 f = (texture2D(F, uv).rg - 0.50196) * k; vec4 a = texture2D(A, uv - t * f); vec4 b = texture2D(B, uv + (1.0 - t) * f); gl_FragColor = mix(a, b, t); }');
    if (!vs || !fs) return null;
    var pr = gl.createProgram(); gl.attachShader(pr, vs); gl.attachShader(pr, fs); gl.linkProgram(pr);
    if (!gl.getProgramParameter(pr, gl.LINK_STATUS)) return null;
    gl.useProgram(pr);
    var buf = gl.createBuffer(); gl.bindBuffer(gl.ARRAY_BUFFER, buf); gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 1, -1, -1, 1, 1, 1]), gl.STATIC_DRAW);
    var lp = gl.getAttribLocation(pr, 'p'); gl.enableVertexAttribArray(lp); gl.vertexAttribPointer(lp, 2, gl.FLOAT, false, 0, 0);
    gl.uniform1i(gl.getUniformLocation(pr, 'A'), 0); gl.uniform1i(gl.getUniformLocation(pr, 'B'), 1); gl.uniform1i(gl.getUniformLocation(pr, 'F'), 2);
    var R = { gl: gl, uT: gl.getUniformLocation(pr, 't'), uK: gl.getUniformLocation(pr, 'k'), tex: new Array(N), flow: new Array(N), zero: null };
    R.make = function (src, isFlow) {
      var tx = gl.createTexture(); gl.bindTexture(gl.TEXTURE_2D, tx);
      gl.pixelStorei(gl.UNPACK_PREMULTIPLY_ALPHA_WEBGL, !isFlow);
      gl.pixelStorei(gl.UNPACK_COLORSPACE_CONVERSION_WEBGL, isFlow ? gl.NONE : gl.BROWSER_DEFAULT_WEBGL);
      if (src instanceof Uint8Array) gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, 1, 1, 0, gl.RGBA, gl.UNSIGNED_BYTE, src);
      else gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, src);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
      return tx;
    };
    R.zero = R.make(new Uint8Array([128, 128, 128, 255]), true);          // flux nul (fondu simple) tant qu'un flux manque
    R.draw = function (i, j, t) {
      var w = cv.width, h = cv.height; gl.viewport(0, 0, w, h);
      gl.clearColor(0, 0, 0, 0); gl.clear(gl.COLOR_BUFFER_BIT);
      var a = R.tex[i] || R.tex[j], b = R.tex[j] || R.tex[i], both = !!(R.tex[i] && R.tex[j]);
      if (!a) return;
      var K = 255 / 127 * CFG.flowMax;
      gl.uniform2f(R.uK, K / (natW || 720), K / (natH || 402)); gl.uniform1f(R.uT, both ? t : 0);
      gl.activeTexture(gl.TEXTURE0); gl.bindTexture(gl.TEXTURE_2D, a);
      gl.activeTexture(gl.TEXTURE1); gl.bindTexture(gl.TEXTURE_2D, b);
      gl.activeTexture(gl.TEXTURE2); gl.bindTexture(gl.TEXTURE_2D, (both && R.flow[i]) || R.zero);
      gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);
    };
    R.loadFlows = function () {
      for (var i = 0; i < N; i++) (function (i) {
        var im = new Image();
        im.onload = function () { try { R.flow[i] = R.make(im, true); if (drawn.i === i) { drawn.i = -1; drawAngle(angle.x); } } catch (e) {} };
        im.src = 'img/car/flow_' + pad(i) + '.png';
      })(i);
    };
    cv.addEventListener('webglcontextlost', function (e) { e.preventDefault(); });
    cv.addEventListener('webglcontextrestored', function () { location.reload(); });    // rarissime : on repart proprement
    return R;
  }
  var CAR = CFG.car || { name: '207', model: 'Peugeot 207' };
  document.title = CAR.name;
  $$('.car-name').forEach(function (e) { e.textContent = CAR.name; });
  $$('.car-model').forEach(function (e) { e.textContent = CAR.model; });
  var frameW = 0, natW = 0, natH = 0, frameGen = 0;
  function wantFrameW(nw) {
    var w = Math.ceil(ttCanvas.offsetWidth * SC * (window.devicePixelRatio || 1) / 16) * 16;
    return (!w || w >= nw) ? nw : Math.max(320, w);
  }
  function setFrameSize(w) {
    frameW = w; ttCanvas.width = w; ttCanvas.height = Math.round(w * natH / natW);
    drawn.i = -1; if (typeof angle !== 'undefined' && angle) drawAngle(angle.x);
  }
  function loadFrame(f) {
    var gen = frameGen, im = new Image();
    im.src = 'img/car/hero_' + pad(f) + '.webp';
    var done = function (bm) {
      if (gen !== frameGen) { if (bm && bm.close) try { bm.close(); } catch (e) {} return; }   // redécodage plus récent en cours
      if (GLR) {                                                                      // vue -> texture, copie libérée
        var ot = GLR.tex[f]; GLR.tex[f] = GLR.make(bm, false); if (ot) GLR.gl.deleteTexture(ot);
        if (bm && bm.close) try { bm.close(); } catch (e) {}
        bitmaps[f] = true;
      } else {
        var old = bitmaps[f]; bitmaps[f] = bm;
        if (old && old !== bm && old.close) try { old.close(); } catch (e) {}
      }
      drawn.i = -1; drawAngle(angle.x);
    };
    var keep = function () {
      if (!natW && im.naturalWidth) { natW = im.naturalWidth; natH = im.naturalHeight; setFrameSize(wantFrameW(natW)); }
      if (!window.createImageBitmap) { done(im); return; }
      var pm = GLR ? { premultiplyAlpha: 'premultiply' } : {}, p;
      if (frameW && frameW < im.naturalWidth) { pm.resizeWidth = frameW; pm.resizeHeight = ttCanvas.height; pm.resizeQuality = 'medium'; }
      try { p = createImageBitmap(im, pm); } catch (e) { p = createImageBitmap(im); }
      p.then(done, function () { createImageBitmap(im).then(done, function () { done(im); }); });
    };
    if (im.decode) im.decode().then(keep, function () { im.onload = keep; if (im.complete && im.naturalWidth) keep(); });
    else { im.onload = keep; }
  }
  function frameOrder() {
    var c = Math.round((((angle.x / STEP) % N) + N) % N) % N, order = [c];
    for (var k = 1; k <= N / 2; k++) { order.push((c + k) % N); if (k < N / 2) order.push((c - k + N) % N); }
    return order;
  }
  function refitFrames() {
    if (!natW || !frameW) return;
    var w = wantFrameW(natW);
    if (w <= frameW * 1.05 && w >= frameW * 0.8) return;
    frameGen++; setFrameSize(w);
    frameOrder().forEach(loadFrame);
  }
  ttCanvas.width = 600; ttCanvas.height = 335;
  /* position par défaut = 3/4 avant droit */
  var HOME = (CFG.homeView != null ? CFG.homeView : 6) * STEP;
  function homeTarget() { return angle.x + ((((HOME - angle.x) % 360) + 540) % 360 - 180); }
  var angle = new Spring(HOME, { precision: 0.05, onUpdate: function (d) { drawAngle(d); } });
  frameOrder().forEach(loadFrame);          // la vue courante d'abord, puis le reste en s'éloignant
  if (GLR) setTimeout(GLR.loadFlows, 1500);  // les flux après les vues (la voiture s'affiche d'abord)
  function drawAngle(deg) {
    var p = ((deg / STEP) % N + N) % N, i = Math.floor(p) % N, j = (i + 1) % N, t = p - Math.floor(p);
    t = lite ? (t < 0.5 ? 0 : 1) : GLR ? Math.round(t * 256) / 256 : Math.round(t * 64) / 64;   // WebGL : 256 positions entre deux vues
    if (t === 1) { i = j; j = (i + 1) % N; t = 0; }
    if (GLR) {
      if (!GLR.tex[i] && !GLR.tex[j]) return;
      var fk = GLR.flow[i] ? 1 : 0;
      if (drawn.i === i && drawn.j === j && drawn.t === t && drawn.f === fk) return;
      drawn.i = i; drawn.j = j; drawn.t = t; drawn.f = fk;
      GLR.draw(i, j, t);
      return;
    }
    var A = bitmaps[i], B = bitmaps[j];
    if (!A && !B) return;
    if (!A) { A = B; t = 0; } else if (!B) { t = 0; }
    if (drawn.i === i && drawn.j === j && drawn.t === t) return;   // rien n'a changé : pas de redessin
    drawn.i = i; drawn.j = j; drawn.t = t;
    var w = ttCanvas.width, h = ttCanvas.height;
    ttCtx.globalCompositeOperation = 'source-over'; ttCtx.globalAlpha = 1;
    ttCtx.clearRect(0, 0, w, h);
    if (t === 0) { ttCtx.drawImage(A, 0, 0, w, h); return; }
    // fondu enchaîné A·(1−t) + B·t (mode « lighter » en alpha prémultiplié)
    ttCtx.globalAlpha = 1 - t; ttCtx.drawImage(A, 0, 0, w, h);
    ttCtx.globalCompositeOperation = 'lighter'; ttCtx.globalAlpha = t; ttCtx.drawImage(B, 0, 0, w, h);
    ttCtx.globalCompositeOperation = 'source-over'; ttCtx.globalAlpha = 1;
  }
  angle.onUpdate = drawAngle;
  drawAngle(angle.x);
  /* ----- rotation automatique : tour complet en continu, très fluide, reprise 2,5 s après le dernier geste ----- */
  var AUTO_DPS = 12, autoLast = 0, autoDraw = 0, autoPause = 0, autoV = 0, dragging = false;   // 12 °/s = un tour en 30 s
  function autoOk() {
    return !Motion.reduced && !dragging && current === 'home' && !document.hidden && visible !== false && !angle.live &&
      !$('#sheet-scrim').classList.contains('on') && !readyOpen() && Date.now() >= autoPause;
  }
  function autoTick(t) {
    requestAnimationFrame(autoTick);
    var dt = autoLast ? Math.min(0.1, (t - autoLast) / 1000) : 0; autoLast = t;
    var ok = false; try { ok = autoOk(); } catch (e) {}
    if (!ok) { autoV = 0; return; }
    autoV += (AUTO_DPS - autoV) * Math.min(1, dt * 2.5);                 // démarrage progressif, sans à-coup
    angle.x += autoV * dt;                                               // la valeur avance en continu (jamais bloquée sur une vue)
    if (GLR || t - autoDraw >= 33) { autoDraw = t; drawAngle(angle.x); } // WebGL : à chaque image ; sinon plafonné à ~30 images/s
  }
  requestAnimationFrame(autoTick);
  (function () {
    var el = $('#turntable'), tr, sx, base, id = null, moved = false;
    el.addEventListener('pointerdown', function (e) {
      id = e.pointerId; sx = e.clientX; base = angle.x; moved = false; dragging = true;
      angle.stop();
      tr = new Motion.Tracker(); tr.add(e.clientX, 0); try { el.setPointerCapture(id); } catch (er) {}
    });
    el.addEventListener('pointermove', function (e) {
      if (e.pointerId !== id) return; tr.add(e.clientX, 0);
      var dx = e.clientX - sx; if (Math.abs(dx) > 6) moved = true;
      angle.set(base + dx * 0.5);                 // la voiture suit le doigt : doigt vers la droite = voiture qui tourne vers la droite
    });
    function end(e) {
      if (e.pointerId !== id) return; id = null; dragging = false; autoPause = Date.now() + 2500; autoV = 0;
      if (!moved) { showPage('vehicle', $('#card-car')); return; }
      var v = tr.velocity().x * 0.5; // deg/s
      var proj = angle.x + Motion.project(v, 0.995);
      var target = Math.round(proj / STEP) * STEP;
      angle.to(target, { response: 0.5, damping: 1, velocity: v, onRest: function () { store.set('angle', angle.x % 360); autoPause = Date.now() + 2500; } });
      $('#tt-hint').style.opacity = 0;
    }
    el.addEventListener('pointerup', end); el.addEventListener('pointercancel', end);
  })();
  function introSpin() { autoV = 0; }   // plus de petit tour d'accueil : la rotation automatique s'en charge

  /* ======================= média ======================= */
  var media = {}, playGuessT = null;
  function renderMedia(m) {
    media = m || {};
    if (playGuessT && media.playing === undefined) media.playing = playGuessT.v;
    var has = !!(media.title), isRadio = media.kind === 'radio';
    setText('#m-title', has ? media.title : 'Aucune lecture');                 // v1.21 : n'écrit que ce qui change
    setText('#m-artist', has ? (media.artist || '') : 'Touchez une source pour commencer');
    setText('#m-source', media.source || '');
    var pb = $('#m-play'), pi = media.playing ? 'pause' : 'play'; if (pb._ic !== pi) { pb.innerHTML = svg(pi); pb._ic = pi; }   // v1.21
    var art = $('#m-art');
    var bg = $('#m-bg');
    if (media.art) {
      if (art._src !== media.art) { art._src = media.art; art.style.backgroundImage = 'url(' + media.art + ')'; bg.style.backgroundImage = 'url(' + media.art + ')'; }
      if (art._ic) { art.innerHTML = ''; art._ic = null; } bg.classList.add('on');
    } else {
      if (art._src) { art._src = null; art.style.backgroundImage = ''; }
      var ai = isRadio ? 'radio' : 'music'; if (art._ic !== ai) { art.innerHTML = svg(ai); art._ic = ai; } bg.classList.remove('on');
    }
    art.classList.toggle('is-radio', isRadio);
    $('#card-media').classList.toggle('no-progress', !media.dur);
    var p = media.dur ? Math.max(0, Math.min(1, media.pos / media.dur)) : 0;
    $('#m-bar').style.transform = 'scaleX(' + p + ')'; $('#m-bar').style.width = '100%';
    setText('#m-t0', media.dur ? mmss(media.pos) : '');
    setText('#m-t1', media.dur ? '-' + mmss(media.dur - media.pos) : '');
  }
  $('#m-prev').innerHTML = svg('prev'); $('#m-next').innerHTML = svg('next');
  /* Lecture / pause : toujours une bascule. L'icône change tout de suite ; l'état réel (s'il est connu) la corrige. */
  tappable($('#m-play'), function () {
    var nowPlaying = !media.playing;
    playGuessT = { v: nowPlaying }; setTimeout(function () { playGuessT = null; }, 2500);
    $('#m-play').innerHTML = svg(nowPlaying ? 'pause' : 'play'); $('#m-play')._ic = nowPlaying ? 'pause' : 'play'; media.playing = nowPlaying;
    Bridge.media('toggle');
  });
  tappable($('#m-prev'), function () { Bridge.media('prev'); });
  tappable($('#m-next'), function () { Bridge.media('next'); });
  // pochette : ouvre l'appli qui joue (radio, Spotify…), sinon l'appli Musique choisie
  tappable($('#m-art'), function () {
    if (media.pkg) { var p = appByPkg(media.pkg); if (p) { openApp(p); return; } Bridge.launchPkg(media.pkg); return; }
    var a = findTheme(media.kind === 'radio' ? 'radio' : 'music'); if (a) openApp(a); else toast('Choisis ton appli Musique dans les réglages');
  });
  Bridge.on('media', renderMedia);
  function mmss(t) { t = Math.max(0, Math.round(t || 0)); return Math.floor(t / 60) + ':' + pad(t % 60); }
  /* applis par défaut choisies à la main (Réglages > Applis par défaut) ; sinon reconnaissance par le nom */
  function roleApp(th) { var r = store.get('roles', {}) || {}; return r[th] && appByKey[r[th]] ? appByKey[r[th]] : null; }
  function findTheme(th) {
    var ra = roleApp(th); if (ra) return ra;
    for (var i = 0; i < apps.length; i++) if (apps[i].theme === th && !apps[i].virtual) return apps[i];
    return null;
  }
  function appByPkg(pkg) { for (var i = 0; i < apps.length; i++) if (apps[i].pkg === pkg) return apps[i]; return null; }

  function renderQuick() {
    var q = $('#quick'); q.innerHTML = '';
    ['radio', 'eq', 'car', 'settings'].forEach(function (th) {
      var a = th === 'car' ? VIRTUAL[0] : findTheme(th); if (!a) a = th === 'settings' ? VIRTUAL[1] : null;
      var b = document.createElement('button'); b.className = 'qbtn press';
      var lbl = { radio: 'Radio', eq: 'Son', car: 'Véhicule', settings: 'Réglages' }[th];
      b.innerHTML = (a ? Icons.appIcon(a, 50) : Icons.appIcon({ theme: th }, 50)) + '<span>' + lbl + '</span>';
      tappable(b, function () { if (a) openApp(a, b); else toast('App introuvable sur le poste'); });
      q.appendChild(b);
    });
  }

  /* ======================= véhicule : ordinateur de bord (page « Véhicule ») ======================= */
  function renderVehicle() { renderTrip(); }
  function frDate(d) { if (typeof d === 'string') d = new Date(d + 'T12:00:00'); return pad(d.getDate()) + '/' + pad(d.getMonth() + 1) + '/' + d.getFullYear(); }
  /* ======================= ordinateur de bord (CAN, profil VW) ======================= */
  var car = store.get('car', {}) || {};   // dernières valeurs connues (gardées au redémarrage)
  function fmtN(v, dec) { if (v == null || v === '' || isNaN(v)) return null; return Number(v).toFixed(dec || 0).replace('.', ',').replace(/\B(?=(\d{3})+(?!\d))/g, '\u202f'); }
  var TRIP = [
    ['outside', 'Extérieur', 'temp', function (v) { return fmtN(v, 1) + '°'; }, function (v) { return v <= 3; }],
    ['coolant', 'Liquide de refroid.', 'temp', function (v) { return fmtN(v) + '°'; }, function (v) { return v > 110; }],
    ['oil', 'Huile moteur', 'temp', function (v) { return fmtN(v) + '°'; }, function (v) { return v > 130; }],
    ['battery', 'Batterie', 'battery', function (v) { return fmtN(v, 1) + ' V'; }, function (v) { return v < 11.8; }],
    ['range', 'Autonomie', 'fuel', function (v) { return fmtN(v) + ' km'; }, function (v) { return v < 60; }],
    ['cons', 'Consommation moy.', 'gauge', function (v) { return fmtN(v, 1) + ' L/100'; }, null],
    ['avg', 'Vitesse moyenne', 'gauge', function (v) { return fmtN(v) + ' km/h'; }, null],
    ['odo', 'Kilométrage', 'car', function (v) { return fmtN(v) + ' km'; }, null],
    ['fuel', 'Carburant restant', 'fuel', function (v) { return fmtN(v) + ' L'; }, function (v) { return v < 7; }],
    ['fuel_pct', 'Carburant restant', 'fuel', function (v) { return fmtN(v) + ' %'; }, function (v) { return v < 12; }],   // v1.27 : applis CAN qui donnent le niveau en %
    ['rpm', 'Régime moteur', 'gauge', function (v) { return fmtN(v) + ' tr/min'; }, null],
    ['speed', 'Vitesse', 'gauge', function (v) { return fmtN(v) + ' km/h'; }, null],
    // frein à main retiré : l'Ibiza ne l'envoie pas sur le CAN (reste « Pas de freins » même dans CarCan)
    ['belt', 'Ceinture conducteur', 'check', function (v) { return /ne pas|non|pas attach/i.test(v) ? 'Non bouclée' : v; }, function (v) { return /ne pas|non|pas attach/i.test(v); }],
    ['washer', 'Lave-glace', 'check', function (v) { return v; }, function (v) { return !/normal|ok/i.test(v); }]
  ];
  var TRIP_CORE = ['outside', 'battery', 'fuel', 'odo'];
  function renderTrip() {
    var h = '<div class="trip-grid">';
    TRIP.forEach(function (t) {
      var val = null, warn = false;
      var has = car[t[0]] != null;
      if (!has && TRIP_CORE.indexOf(t[0]) < 0) return;   // ce que le boîtier ne fournit pas n'est pas affiché
      if (t[0] === 'fuel' && !has && car.fuel_pct != null) return;   // niveau connu en % : pas de case « litres » vide
      if (car[t[0]] != null) { val = t[3](car[t[0]]); warn = t[4] ? t[4](car[t[0]]) : false; }
      h += '<div class="trip' + (warn ? ' warn' : '') + (val ? '' : ' empty') + '">' + svg(t[2]) + '<div><span>' + t[1] + '</span><b>' + (val || '—') + '</b></div></div>';
    });
    h += '</div>';
    var when = car.at ? new Date(car.at) : null;
    var ci = Bridge.canAppSupported() ? (Bridge.canAppInfo() || {}) : { hcn: true };
    // v1.27 : poste dont l'appli CAN n'est pas encore connue : l'apprentissage est proposé là où les cases sont vides
    if (!ci.has && !ci.hcn && !Bridge.canLive()) h = '<div class="veh-learn"><div class="vl-top">' + svg('gauge') + '<b>Ordinateur de bord pas encore lu</b></div><span>Montre une fois au lanceur l\'appli « voiture » de ton autoradio : il lira ensuite carburant, batterie, kilométrage tout seul. 2 minutes.</span><button class="sbtn press lrn-go" id="trip-learn">Apprendre l\'ordinateur de bord</button></div>' + h;
    h += '<div class="trip-foot"><span>' + (when ? 'Mis à jour ' + pad(when.getHours()) + ':' + pad(when.getMinutes()) + (car.src ? ' · ' + esc(car.src) : '') : 'Aucune donnée CAN reçue pour l\'instant.') + '</span>' +
      '<span class="trip-btns"><button class="chip-btn press" id="trip-refresh">' + svg('check') + 'Actualiser</button><button class="chip-btn press" id="trip-open">' + svg('car') + esc(ci.has && ci.label ? String(ci.label).slice(0, 14) : ci.hcn ? 'CarCan' : 'Appli CAN') + '</button></span></div>';
    $('#tripview').innerHTML = h;
    if ($('#trip-learn')) tappable($('#trip-learn'), function () { canAppSheet(false); });
    tappable($('#trip-refresh'), function () {
      if (!Bridge.canRefreshPossible()) {
        if (Bridge.canAppSupported() && !ci.has && !ci.hcn) { canAppSheet(false); return; }
        toast('Active l\'accessibilité du lanceur pour lire l\'appli CAN'); return;
      }
      Bridge.canRefresh();
    });
    tappable($('#trip-open'), function () {
      var a = roleApp('can'); if (a) { openApp(a); return; }
      toast('Choisis l\'appli CAN dans Réglages > Applis par défaut'); showPage('settings', $('#trip-open'));
    });
  }
  tappable($('#btn-vehicle'), function () { showPage('vehicle', $('#btn-vehicle')); });
  $('#btn-vehicle').innerHTML = svg('car') + 'Véhicule';


  /* ======================= réglages du lanceur ======================= */
  function renderSettings() {
    var st = Bridge.state(), p = st.perms || {};
    var glass = store.get('glass', 'sim');
    var rows = [
      '<div class="hdr">Installation</div>',
      row('check', 'Assistant de démarrage', store.get('setupDone', false) ? '' : 'À faire', 'setup'),
      row('home', 'Lanceur par défaut', p.home ? 'Actif' : 'Choisir', 'sys:home'),
      row('music', 'Accès aux notifications (média)', p.notif ? 'Autorisé' : 'À autoriser', 'sys:notif'),
      row('car', 'Lecture CAN (accessibilité)', p.access ? 'Autorisé' : 'À autoriser', 'access'),
      row('home', 'Revenir au lanceur d\'origine / désinstaller', '', 'sys:leave'),
      '<div class="hdr">Affichage</div>',
      row('brush', 'Personnaliser (fond, couleurs)', '', 'custom'),
      row('brush', 'Couleur de l\'interface', accentName(), 'custom'),
      row('grid', 'Disposition de l\'accueil', layoutName(), 'layout'),
      row('grid', 'Bibliothèque d\'apps', store.get('appsRows', 2) === 2 ? '2 lignes · grandes icônes' : '3 lignes', 'appsrows'),
      row('grid', 'Taille de l\'interface', { normal: 'Normale', grand: 'Grande', xl: 'Très grande' }[store.get('zoom', 'grand')], 'zoom'),
      row('sun', 'Thème', { auto: 'Auto (phares / nuit)', dark: 'Sombre', light: 'Clair' }[store.get('theme', 'auto')], 'theme'),
      row('home', 'Fond d\'écran', { match: 'Suit le thème', dark: 'Sombre', light: 'Clair', day: 'Jour', evening: 'Soir', sunset: 'Couchant', night: 'Nuit', auto: 'Selon l\'heure', custom: 'Perso' }[store.get('wall', 'match')] || '', 'wall'),
      row('sun', 'Effet verre', { sim: 'Rapide', real: 'Flou réel', off: 'Désactivé' }[glass], 'glass'),
      toggleRow('sun', 'Carte « Prêt à partir » au démarrage', store.get('ready', true), 'ready'),
      row('gauge', 'Lecture auto de l\'ordinateur de bord', { off: 'Désactivée', boot: 'Au démarrage', '15': 'Démarrage + 15 min' }[store.get('autoread', 'boot')], 'autoread'),
      toggleRow('sun', 'Mode léger (processeur lent)', store.get('lite', false), 'lite'),
      toggleRow('dash', 'Masquer la barre système de l\'autoradio', store.get('immersive', true), 'immersive'),
      row('files', 'Liste des applis pour les icônes perso', '', 'icons:list'),
      row('grid', 'Recharger les icônes perso', '', 'icons:reload'),
      '<div class="t-cap" style="padding:0 10px 6px">Dossier : ' + esc(Bridge.iconDir()) + '/&lt;paquet&gt;.png</div>',
      '<div class="hdr">Applis par défaut</div>',
      roleRow('music', 'Musique'), roleRow('radio', 'Radio'), roleRow('nav', 'Navigation'), roleRow('phone', 'Téléphone'), roleRow('eq', 'Son / égaliseur'), roleRow('can', 'Appli CAN (infos véhicule)'),
      '<div class="hdr">Données CAN du poste</div>',
      row('bug', 'Ordinateur de bord en direct (journal)', !Bridge.canLogs() ? 'Non autorisé' : Bridge.canLive() ? 'Actif' : 'Autorisé · en attente', 'can:logs'),
      Bridge.canAppSupported() ? row('gauge', 'Apprendre l\'ordinateur de bord (appli CAN du poste)', (Bridge.canAppInfo() || {}).has ? 'Appris' : '2 min', 'canapp') : '',
      '<div class="hdr">Diagnostic</div>',
      row('sun', 'Afficher la carte « Prêt à partir »', '', 'test:ready'),
      row('bug', 'Exporter le journal (fichier ibiza_diag.txt)', '', 'diag:export'),
      row('bug', 'Vider le journal', '', 'diag:clear'),
      '<div class="diag" id="diag"></div>',
      '<div class="hdr">À propos</div>',
      row('settings', 'Paramètres Android', '', 'sys:android'),
      '<div class="t-cap" style="padding:6px 10px 0">Modèle 3D « Peugeot 207 » par romanian_guy_0069 (Sketchfab), licence CC BY 4.0, version argent. Rendu en images 2D.</div>'
    ];
    $('#settings-list').innerHTML = rows.join('');
    $('#diag').textContent = Bridge.diag() || '';
    $$('#settings-list [data-act]').forEach(function (el) { tappable(el, function () { act(el.getAttribute('data-act'), el); }); });
  }
  function roleRow(th, t) {
    var a = roleApp(th), auto = a ? null : (th === 'can' ? null : findTheme(th));
    return row(th === 'can' ? 'car' : th === 'eq' ? 'eq' : th, t, a ? esc(a.label) : auto ? 'Auto : ' + esc(auto.label) : 'Choisir', 'role:' + th);
  }
  function roleSheet(th, label) {
    var list = apps.filter(function (a) { return !a.virtual; });
    var r = store.get('roles', {}) || {};
    var h = '<div class="t-headline">' + label + '</div><div class="t-sub">Touche l\'appli à utiliser.</div><div class="pick-list">' +
      '<div class="pick press" data-k=""><div class="aicon aicon-raw noimg" style="width:44px;height:44px"><b>A</b></div><span>Automatique</span></div>' +
      list.map(function (a) { return '<div class="pick press' + (r[th] === key(a) ? ' on' : '') + '" data-k="' + esc(key(a)) + '">' + Icons.appIcon(a, 44) + '<span>' + esc(a.label) + '</span></div>'; }).join('') + '</div>';
    openSheet(h, function (s) {
      $$('.pick', s).forEach(function (el) { tappable(el, function () {
        var rr = store.get('roles', {}) || {}, k = el.getAttribute('data-k');
        if (k) rr[th] = k; else delete rr[th];
        store.set('roles', rr); closeSheet(); renderDock(); renderQuick(); renderSettings(); alignGlass();
      }); });
    });
  }
  function row(ic, t, val, act) { return '<div class="row btn" data-act="' + act + '">' + svg(ic) + '<div class="grow">' + t + '</div><div class="val">' + val + '</div>' + (val !== '' || true ? '' : '') + '</div>'; }
  /* ---------- page « Personnaliser » : fond d'écran, couleur de l'interface, thème et icônes perso ---------- */
  var ACCENTS = [['', 'Par défaut'], ['#0091ff', 'Bleu'], ['#00d2e0', 'Turquoise'], ['#30d158', 'Vert'], ['#b7cc3c', 'Lime'],
    ['#ffd600', 'Jaune'], ['#ff9230', 'Orange'], ['#ff4245', 'Rouge'], ['#ff375f', 'Rose'], ['#6d7cff', 'Violet']];
  function applyAccent() {
    var a = store.get('accent', '');
    if (!/^#[0-9a-f]{6}$/i.test(a || '')) a = '';
    root.classList.toggle('accent', !!a);
    if (a) root.style.setProperty('--accent', a); else root.style.removeProperty('--accent');
  }
  function accentName() { var a = store.get('accent', ''); for (var i = 0; i < ACCENTS.length; i++) if (ACCENTS[i][0] === a) return ACCENTS[i][1]; return 'Par défaut'; }

  function renderCustom() {
    /* colonne de droite : apparence */
    var sel = store.get('wall', 'match');
    var walls = WALLS.map(function (w) { var th = w[0] === 'match' ? 'dark' : w[0]; return '<div class="wthumb press' + (sel === w[0] ? ' on' : '') + '" data-w="' + w[0] + '" style="background-image:' + (w[0] === 'match' ? 'url(img/walls/light_t.jpg),url(img/walls/dark_t.jpg)' : 'url(img/walls/' + th + '_t.jpg)') + ';background-size:50% 100%,50% 100%,cover;background-position:0 0,100% 0,0 0;background-repeat:no-repeat"><span>' + w[1] + '</span></div>'; }).join('') +
      '<div class="wthumb auto press' + (sel === 'auto' ? ' on' : '') + '" data-w="auto"><span>Selon l\'heure</span></div>' +
      '<div class="wthumb usb press' + (sel === 'custom' ? ' on' : '') + '" data-w="usb">' + svg('files') + '<span>Clé USB…</span></div>';
    var acc = store.get('accent', '');
    var sw = ACCENTS.map(function (a) { return '<button class="swatch press' + (acc === a[0] ? ' on' : '') + (a[0] ? '' : ' sw-def') + '" data-ac="' + a[0] + '" aria-label="' + a[1] + '"' + (a[0] ? ' style="background:' + a[0] + '"' : '') + '></button>'; }).join('');
    var th = store.get('theme', 'auto');
    var seg = [['auto', 'Auto'], ['dark', 'Sombre'], ['light', 'Clair']].map(function (t) { return '<button class="seg-b' + (th === t[0] ? ' is-on' : '') + '" data-th="' + t[0] + '">' + t[1] + '</button>'; }).join('');
    $('#cust-look').innerHTML =
      '<div class="hdr">Fond d\'écran</div><div class="walls">' + walls + '</div>' +
      '<div class="hdr">Couleur de l\'interface <span class="hdr-val">' + accentName() + '</span></div><div class="swatches">' + sw + '</div>' +
      '<div class="hdr">Thème</div><div class="seg cust-seg">' + seg + '</div>' +
      '<div class="t-cap cust-note">Auto : clair le jour, sombre quand les phares sont allumés ou la nuit.</div>' +
      '<div class="hdr">Icônes perso</div>' +
      '<div class="t-sub cust-note">Tu peux remplacer l\'icône de chaque appli par ta propre image (PNG carré). ' +
      '« Liste des applis » te donne le nom de fichier de chaque icône et le dossier où les déposer.</div>' +
      '<div class="cust-btns"><button class="chip-btn press" data-ic="list">' + svg('files') + 'Liste des applis</button>' +
      '<button class="chip-btn press" data-ic="reload">' + svg('grid') + 'Recharger</button></div>';
    var look = $('#cust-look');
    $$('[data-w]', look).forEach(function (el) { tappable(el, function () {
      var w = el.getAttribute('data-w');
      if (w === 'usb') { $('#wall-file').click(); return; }
      store.set('wall', w); applyWall();
      $$('[data-w]', look).forEach(function (o) { o.classList.toggle('on', o === el); });
    }); });
    $$('[data-ac]', look).forEach(function (el) { tappable(el, function () {
      store.set('accent', el.getAttribute('data-ac')); applyAccent();
      $$('[data-ac]', look).forEach(function (o) { o.classList.toggle('on', o === el); });
      $('.hdr-val', look).textContent = accentName();
    }); });
    $$('[data-th]', look).forEach(function (el) { tappable(el, function () {
      store.set('theme', el.getAttribute('data-th')); applyTheme();
      $$('[data-th]', look).forEach(function (o) { o.classList.toggle('is-on', o === el); });
    }); });
    $$('[data-ic]', look).forEach(function (el) { tappable(el, function () { act('icons:' + el.getAttribute('data-ic'), el); }); });
    alignGlass();
  }
  tappable($('#btn-custom'), function () { showPage('custom', $('#btn-custom')); });
  $('#btn-custom').innerHTML = svg('brush') + '<span>Personnaliser</span>';
  applyAccent();

  /* v1.24.3 : autorisation « Lecture CAN ». Certains postes (ex. Autochips 825X_Pro, Android 9) n'ont plus de page
     Accessibilité : on explique la solution par adb (une seule fois) au lieu d'ouvrir l'accueil des Paramètres. */
  /* v1.27 : Android 13 et plus. Une appli installée depuis un fichier APK (clé USB) n'a pas le droit d'activer
     l'accessibilité : Android affiche « Paramètre restreint » et l'interrupteur reste grisé. Le déblocage est caché dans
     la fiche de l'appli (menu ⋮), et n'y apparaît qu'APRÈS un premier essai refusé : on guide le client pas à pas. */
  var AH = { open: false };
  function accessHintSheet() {
    openSheet('<div class="t-headline">Autoriser la lecture CAN</div>' +
      '<div class="t-sub">Sur Android 13 et plus, cette autorisation est bloquée pour les applis installées depuis une clé USB. Trois gestes pour la débloquer :</div>' +
      '<div class="lrn-list">' + [
        'Ouvre <b>Accessibilité</b> et touche « Car Launcher ». Si Android répond « Paramètre restreint », touche OK et reviens ici.',
        'Ouvre la <b>fiche de l\'appli</b>, touche les trois points <b>⋮</b> en haut à droite, puis « Autoriser les paramètres restreints ».',
        'Rouvre <b>Accessibilité</b> : « Car Launcher » peut maintenant être activé.'
      ].map(function (t, i) { return '<div class="cm-row"><div class="cm-num">' + (i + 1) + '</div><div class="cm-l cm-wrap"><span>' + t + '</span></div></div>'; }).join('') + '</div>' +
      '<div class="t-cap">Pas de message « Paramètre restreint » ? Alors active simplement « Car Launcher » à l\'étape 1. Le même blocage peut toucher l\'autorisation Musique (notifications) : même solution.</div>' +
      '<div class="sheet-actions lrn-act"><button class="sbtn press lrn-go" data-a="acc">Accessibilité</button><button class="sbtn press" data-a="app">Fiche de l\'appli</button><button class="sbtn press" data-a="x">Fermer</button></div>', function (s) {
        s.classList.add('sheet-learn'); AH.open = true;
        $$('[data-a]', s).forEach(function (b) { b.onclick = function () {
          var k = b.getAttribute('data-a');
          if (k === 'acc') askAccess(true);
          else if (k === 'app') Bridge.openSystem('appinfo');
          else { AH.open = false; closeSheet(); if (!setupBack() && current === 'settings') setTimeout(renderSettings, 300); }
        }; });
      });
  }
  Bridge.on('resume', function () {          // retour des Paramètres : si c'est autorisé, la fiche d'aide se ferme toute seule
    if (!AH.open) return;
    if (!$('#sheet-scrim').classList.contains('on') || !$('#sheet [data-a="acc"]')) { AH.open = false; return; }
    if (((Bridge.state() || {}).perms || {}).access) { AH.open = false; closeSheet(); toast('Lecture CAN autorisée'); if (!setupBack() && current === 'settings') setTimeout(renderSettings, 300); }
  });
  function askAccess(skipHint) {
    if (skipHint !== true && Bridge.accessHint()) { accessHintSheet(); return; }
    var r = Bridge.openAccess();
    if (r === 'on') { toast('Lecture CAN déjà autorisée'); return; }
    if (r === 'enabled') { toast('Lecture CAN autorisée'); setTimeout(function () { if (current === 'settings') renderSettings(); }, 800); setupBack(); return; }
    if (r !== 'missing') return;
    openSheet('<div class="t-headline">Autoriser la lecture CAN</div>' +
      '<div class="t-sub">Le fabricant de ce poste a retiré la page <b>Accessibilité</b> des Paramètres Android. ' +
      'Sans cette autorisation, le lanceur ne peut pas lire les infos de la voiture.</div>' +
      '<div class="hchoice acc-opt"><b>Avec un ordinateur, une seule fois</b>' +
      '<span>Active le débogage USB du poste, branche-le à l\'ordinateur, puis tape :</span>' +
      '<code class="acc-cmd">' + esc(Bridge.accessCommand()) + '</code>' +
      '<span>Touche ensuite « Réessayer » : le lanceur s\'autorise tout seul, même après un redémarrage. Sans root, et ça s\'annule en désinstallant le lanceur.</span></div>' +
      '<div class="hchoice acc-opt"><b>Sans ordinateur</b><span>Dans les Paramètres Android, cherche « Accessibilité » avec la loupe (si elle existe), puis active « Car Launcher ».</span></div>' +
      '<div class="sheet-actions"><button class="sbtn press" data-a="retry">Réessayer</button><button class="sbtn press" data-a="set">Paramètres</button><button class="sbtn press" data-a="x">Fermer</button></div>', function (s) {
        s.classList.add('sheet-acc');
        $$('[data-a]', s).forEach(function (b) { b.onclick = function () {
          var k = b.getAttribute('data-a'); closeSheet();
          if (k === 'retry') setTimeout(askAccess, 300);
          else if (k === 'set') Bridge.openSystem('settings');
          else setupBack();
        }; });
      });
  }
  /* ---------- assistant de démarrage (première installation) ----------
     Écran d'accueil, musique, lecture CAN, ordinateur de bord. Chaque étape peut être passée ; rouvrable dans Réglages. */
  var SU = { open: false };
  function setupSheet() {
    var st = Bridge.state() || {}, p = st.perms || {};
    // v1.27 : ordinateur de bord. CarCan (postes hcn) est lu sans rien faire ; ailleurs, le client montre son appli CAN une fois
    var ci = Bridge.canAppSupported() ? (Bridge.canAppInfo() || {}) : null, tripOk = !!ci && (ci.has || ci.hcn || Bridge.canLive());
    var steps = [
      ['home', 'Écran d\'accueil', 'Car Launcher s\'ouvre au démarrage et avec la touche Accueil.', !!p.home, 'sys:home', 'Choisir'],
      ['music', 'Musique', 'Titre, pochette et commandes de ce qui joue (Bluetooth, Spotify…).', !!p.notif, 'sys:notif', 'Autoriser'],
      ['car', 'Lecture CAN', 'Vitesse et ordinateur de bord lus sur l\'écran de l\'appli CAN.', !!p.access, 'access', 'Autoriser']
    ];
    if (ci) steps.push(['gauge', 'Ordinateur de bord', ci.has ? 'Carburant, batterie, kilométrage lus dans « ' + esc(ci.label) + ' ».' : ci.hcn ? 'Carburant, batterie, kilométrage lus dans CarCan, automatiquement.'
      : 'Montre une fois l\'appli « voiture » de ton autoradio : carburant, batterie et kilométrage seront lus tout seuls. 2 minutes, contact mis.', tripOk, 'canapp', 'Apprendre']);
    var done = steps.filter(function (s) { return s[3]; }).length;
    openSheet('<div class="su-head"><div><div class="t-headline">Bienvenue dans Car Launcher</div>' +
      '<div class="t-sub">' + (done === steps.length ? 'Tout est prêt.' : 'Quelques réglages pour que tout marche dans ta voiture. Tu peux passer une étape et y revenir plus tard dans les réglages.') + '</div></div>' +
      '<div class="su-count">' + done + '/' + steps.length + '</div></div>' +
      '<div class="su-list">' + steps.map(function (s, i) {
        return '<div class="su-row' + (s[3] ? ' ok' : '') + '"><i class="su-n">' + (s[3] ? svg('check') : (i + 1)) + '</i><div class="grow"><b>' + s[1] + '</b><span>' + s[2] + '</span></div>' +
          (s[3] ? '<em>' + 'Fait' + '</em>' : '<button class="chip-btn press" data-su="' + s[4] + '">' + s[5] + '</button>') + '</div>';
      }).join('') + '</div>' +
      '<div class="sheet-actions"><button class="sbtn press' + (done === steps.length ? ' lrn-go' : '') + '" data-su="done">' + (done === steps.length ? 'C\'est parti' : 'Terminer') + '</button>' +
      '<button class="sbtn press" data-su="later">Plus tard</button></div>', function (s) {
        s.classList.add('sheet-setup'); SU.open = true;
        $$('[data-su]', s).forEach(function (b) { b.onclick = function () {
          var a = b.getAttribute('data-su');
          if (a === 'done' || a === 'later') { SU.open = false; store.set('setupDone', true); closeSheet(); if (a === 'later') toast('Assistant : Réglages du lanceur › Installation'); return; }
          if (a === 'canapp') { SU.back = true; SU.open = false; canAppSheet(false); return; }
          if (a === 'access' && Bridge.accessHint()) { SU.back = true; SU.open = false; accessHintSheet(); return; }
          if (a === 'access') { var r = Bridge.openAccess(); if (r === 'enabled' || r === 'on') { toast('Lecture CAN autorisée'); setupSheet(); } else if (r === 'missing') { SU.back = true; SU.open = false; askAccess(); } return; }
          act(a, b);
        }; });
      });
  }
  Bridge.on('resume', function () { if (SU.open) setTimeout(setupSheet, 350); });    // retour des Paramètres Android : coches à jour
  function setupBack() { if (SU.back && !store.get('setupDone', false)) { SU.back = false; setTimeout(setupSheet, 400); return true; } SU.back = false; return false; }

  /* ---------- v1.27 : « Apprendre l'ordinateur de bord » ----------
     Chaque autoradio a sa propre appli CAN. Le client la choisit, le lanceur l'ouvre avec une barre « Capturer » ;
     de retour ici, il confirme quelle valeur est le carburant, la batterie… (CanApp.java / ScreenRead.java). */
  var CKEYS = [['fuel', 'Carburant (L)'], ['fuel_pct', 'Carburant (%)'], ['range', 'Autonomie'], ['battery', 'Batterie'], ['outside', 'Temp. extérieure'],
    ['coolant', 'Temp. d\'eau'], ['oil', 'Temp. d\'huile'], ['odo', 'Kilométrage'], ['cons', 'Conso. moyenne'], ['avg', 'Vitesse moyenne'], ['rpm', 'Régime moteur'],
    ['speed', 'Vitesse'],
    ['belt', 'Ceinture'], ['washer', 'Lave-glace'], ['handbrake', 'Frein à main']];
  var CKNAME = {}; CKEYS.forEach(function (k) { CKNAME[k[0]] = k[1]; });
  var CM = { res: null, map: [], open: '' };
  function canAppBack() { closeSheet(); if (setupBack()) return; if (current === 'settings') setTimeout(renderSettings, 300); if (current === 'vehicle') setTimeout(renderVehicle, 300); }
  function canAppSheet(all) {
    var ci = Bridge.canAppInfo() || {};
    if (!ci.access) {
      openSheet('<div class="t-headline">Apprendre l\'ordinateur de bord</div>' +
        '<div class="t-sub">Pour lire l\'appli CAN de ton autoradio (carburant, batterie, kilométrage…), le lanceur a besoin de l\'autorisation « Lecture CAN (accessibilité) ».</div>' +
        '<div class="sheet-actions"><button class="sbtn press lrn-go" data-a="go">Autoriser</button><button class="sbtn press" data-a="x">Annuler</button></div>', function (s) {
          s.classList.add('sheet-learn');
          $('[data-a="go"]', s).onclick = function () { closeSheet(); setTimeout(askAccess, 300); };
          $('[data-a="x"]', s).onclick = closeSheet;
        });
      return;
    }
    var list = Bridge.canAppList() || [], sug = list.filter(function (a) { return a.sug; });
    var shown = all || !sug.length ? list : sug;
    var rows = shown.map(function (a) { return '<div class="cm-row cm-app press" data-pkg="' + esc(a.pkg) + '"><div class="cm-l"><b>' + esc(a.label) + '</b><span>' + esc(a.pkg) + '</span></div>' + (a.sug ? '<div class="cm-key">Probable</div>' : '') + '</div>'; }).join('');
    openSheet('<div class="t-headline">Apprendre l\'ordinateur de bord</div>' +
      '<div class="t-sub">Chaque autoradio a sa propre appli « voiture » (CAN). Montre une fois au lanceur où elle affiche le carburant, la batterie ou le kilométrage : il les lira ensuite tout seul. 2 minutes, contact mis, sans ordinateur.</div>' +
      (ci.has ? '<div class="t-cap">Déjà appris : ' + esc(ci.label) + ' (' + ci.fields + ' donnée' + (ci.fields > 1 ? 's' : '') + ')' + (ci.builtin ? ', profil fourni avec le lanceur' : '') + '. Un nouvel apprentissage le remplace.</div>'
        : ci.hcn ? '<div class="t-cap">CarCan est déjà lu automatiquement sur ce poste. Apprends-le seulement s\'il manque des données.</div>' : '') +
      '<div class="hdr cm-hdr">Quelle est l\'appli de la voiture ?</div><div class="cm-list">' + (rows || '<div class="t-cap">Aucune appli trouvée.</div>') + '</div>' +
      '<div class="sheet-actions lrn-act">' + (all || !sug.length ? '' : '<button class="sbtn press" data-a="all">Toutes les applis</button>') +
      (ci.has ? '<button class="sbtn press danger" data-a="forget">Oublier</button>' : '') + '<button class="sbtn press" data-a="x">Annuler</button></div>', function (s) {
        s.classList.add('sheet-learn');
        $$('.cm-app', s).forEach(function (el) { el.onclick = function () { var p = el.getAttribute('data-pkg'), a = shown.filter(function (x) { return x.pkg === p; })[0]; if (a) canAppIntro(a); }; });
        $$('[data-a]', s).forEach(function (b) { b.onclick = function () {
          var a = b.getAttribute('data-a');
          if (a === 'all') canAppSheet(true);
          else if (a === 'forget') { Bridge.canAppClear(); toast('Appli CAN oubliée'); canAppBack(); }
          else canAppBack();
        }; });
      });
  }
  function canAppIntro(a) {
    var ci = Bridge.canAppInfo() || {};
    var how = ci.gestures === false
      ? ['Le lanceur ouvre « ' + esc(a.label) + ' » avec une barre en haut de l\'écran.', 'Va jusqu\'à la page qui affiche les infos de la voiture, comme d\'habitude.', 'Touche « Capturer » sur la barre, puis « Terminer ».']
      : ['Le lanceur ouvre « ' + esc(a.label) + ' » avec une barre en haut de l\'écran.', 'Va jusqu\'à la page qui affiche les infos de la voiture, en touchant <b>lentement</b> (un toucher à la fois) : le lanceur retient le chemin. Si l\'appli ne réagit pas, touche « Main libre » sur la barre et navigue toi-même.', 'Touche « Capturer » sur la barre. S\'il y a d\'autres pages d\'infos, va dessus et capture-les aussi. Puis « Terminer ».'];
    openSheet('<div class="t-headline">' + esc(a.label) + '</div>' +
      '<div class="lrn-list">' + how.map(function (t, i) { return '<div class="cm-row"><div class="cm-num">' + (i + 1) + '</div><div class="cm-l cm-wrap"><span>' + t + '</span></div></div>'; }).join('') + '</div>' +
      '<div class="t-cap">Contact mis ou moteur allumé, pour que les valeurs s\'affichent. Rien n\'est modifié dans le poste.</div>' +
      '<div class="sheet-actions"><button class="sbtn press lrn-go" data-a="go">Commencer</button><button class="sbtn press" data-a="x">Retour</button></div>', function (s) {
        s.classList.add('sheet-learn');
        $('[data-a="x"]', s).onclick = function () { canAppSheet(false); };
        $('[data-a="go"]', s).onclick = function () {
          var r = Bridge.canAppStart(a.pkg) || {};
          if (!r.ok) { toast(r.msg || 'Apprentissage impossible'); if (r.error === 'access') { closeSheet(); setTimeout(askAccess, 300); } return; }
          closeSheet();
        };
      });
  }
  function canMapRows() {
    var res = CM.res, h = '';
    res.pages.forEach(function (pg, p) {
      if (res.pages.length > 1) h += '<div class="cm-page">Page ' + (p + 1) + '</div>';
      pg.cands.forEach(function (c) {
        var k = CM.map[p][c.i] || '', id = p + ':' + c.i;
        h += '<div class="cm-row press' + (k ? ' on' : '') + '" data-id="' + id + '"><div class="cm-l"><b>' + esc(c.value) + (c.unit ? ' ' + esc(c.unit) : '') + '</b><span>' + (c.label ? esc(c.label) : 'sans nom à l\'écran') + '</span></div>' +
          '<div class="cm-key">' + (k ? esc(CKNAME[k] || k) : 'Ignorer') + '</div></div>';
        if (CM.open === id) h += '<div class="cm-chips" data-for="' + id + '">' + CKEYS.map(function (x) { return '<button class="press' + (x[0] === k ? ' is-on' : '') + '" data-k="' + x[0] + '">' + esc(x[1]) + '</button>'; }).join('') +
          '<button class="press' + (k ? '' : ' is-on') + '" data-k="">Ignorer</button></div>';
      });
    });
    return h;
  }
  function canMapCount() { var n = 0; CM.map.forEach(function (m) { for (var i in m) if (m[i]) n++; }); return n; }
  function canMapBind() {
    var sh = $('#sheet'), box = $('.cm-list', sh), top = box.scrollTop;
    box.innerHTML = canMapRows(); box.scrollTop = top;
    $$('.cm-row', box).forEach(function (el) { el.onclick = function () { var id = el.getAttribute('data-id'); CM.open = CM.open === id ? '' : id; canMapBind(); }; });
    $$('.cm-chips button', box).forEach(function (b) { b.onclick = function () {
      var id = b.parentNode.getAttribute('data-for').split(':'), p = +id[0], i = id[1], k = b.getAttribute('data-k');
      if (k) CM.map.forEach(function (m) { for (var j in m) if (m[j] === k) delete m[j]; });      // une donnée = une seule valeur
      if (k) CM.map[p][i] = k; else delete CM.map[p][i];
      CM.open = ''; canMapBind();
    }; });
    var n = canMapCount(), sv = $('[data-a="save"]', sh);
    if (sv) { sv.textContent = n ? 'Enregistrer (' + n + ')' : 'Enregistrer'; sv.style.opacity = n ? '' : '.4'; }
  }
  function canMapSheet(res) {
    if (!res || !res.pkg) return;
    if (!res.pages || !res.pages.length) {
      var stuck = res.taps > 0 && !res.fx && !res.free;      // v1.27.1 : touchers jamais arrivés à l'appli
      openSheet('<div class="t-headline">Aucune page capturée</div>' +
        '<div class="t-sub">' + (stuck ? 'Tes touchers ne sont pas arrivés jusqu\'à « ' + esc(res.label || res.pkg) + ' » : l\'appli est restée sur son premier écran. ' +
          'Recommence et touche <b>« Main libre »</b> sur la barre : tu navigues toi-même jusqu\'à la page des infos, puis « Capturer ». Le lanceur retrouvera le chemin tout seul.'
          : 'Dans « ' + esc(res.label || res.pkg) + ' », va sur la page qui affiche les infos de la voiture puis touche « Capturer » avant « Terminer ». ' +
          'Si la barre disait « aucun texte lisible », cette appli dessine ses chiffres en image : envoie le journal au téléphone, on regardera ton poste.') + '</div>' +
        '<div class="sheet-actions lrn-act"><button class="sbtn press lrn-go" data-a="again">Recommencer</button><button class="sbtn press" data-a="qr">Envoyer le journal</button><button class="sbtn press" data-a="x">Fermer</button></div>', function (s) {
          s.classList.add('sheet-learn');
          $('[data-a="again"]', s).onclick = function () { canAppSheet(false); };
          $('[data-a="qr"]', s).onclick = function () { qrSendSheet('journal'); };
          $('[data-a="x"]', s).onclick = canAppBack;
        });
      return;
    }
    CM.res = res; CM.open = '';
    CM.map = res.pages.map(function (pg) { var m = {}; pg.cands.forEach(function (c) { if (c.key) m[c.i] = c.key; }); return m; });
    var n = canMapCount();
    openSheet('<div class="t-headline">' + (n ? n + ' donnée' + (n > 1 ? 's' : '') + ' reconnue' + (n > 1 ? 's' : '') : 'À toi d\'indiquer les données') + ' dans ' + esc(res.label || res.pkg) + '</div>' +
      '<div class="t-sub">Vérifie chaque ligne : touche-la pour dire à quoi correspond la valeur, ou « Ignorer ». Les valeurs sont celles affichées au moment de la capture.</div>' +
      '<div class="cm-list"></div>' +
      '<div class="sheet-actions lrn-act"><button class="sbtn press lrn-go" data-a="save">Enregistrer</button><button class="sbtn press" data-a="again">Recommencer</button><button class="sbtn press" data-a="x">Annuler</button></div>', function (s) {
        s.classList.add('sheet-learn');
        $$('[data-a]', s).forEach(function (b) { b.onclick = function () {
          var a = b.getAttribute('data-a');
          if (a === 'again') { canAppSheet(false); return; }
          if (a === 'x') { canAppBack(); return; }
          if (!canMapCount()) { toast('Choisis au moins une donnée'); return; }
          var ok = Bridge.canAppSave({ pages: CM.map });
          if (ok !== 'ok') { toast('Enregistrement impossible : ' + ok); return; }
          var ap = apps.filter(function (x) { return x.pkg === res.pkg; })[0];
          if (ap) { var rr = store.get('roles', {}) || {}; rr.can = key(ap); store.set('roles', rr); }      // bouton de la page Véhicule
          toast('Enregistré : lecture de vérification…');
          canAppBack();
          setTimeout(function () { if (Bridge.canRefreshPossible()) { lastAutoRead = Date.now(); Bridge.canRefresh(); } }, 1200);
        }; });
      });
    canMapBind();
  }
  Bridge.on('canlearn', function (d) { var p = Bridge.mock ? d : Bridge.canAppPending(); if (p) canMapSheet(p); });
  Bridge.on('resume', function () { var p = Bridge.canAppPending(); if (p) canMapSheet(p); });

  function toggleRow(ic, t, on, act) { return '<div class="row btn" data-act="toggle:' + act + '">' + svg(ic) + '<div class="grow">' + t + '</div><div class="switch' + (on ? ' on' : '') + '"></div></div>'; }
  function act(a, el) {
    var p = a.split(':');
    if (a === 'sys:leave') {
      openSheet('<div class="t-headline">Revenir au lanceur d\'origine</div><div class="t-sub">Rien n\'est modifié dans le système : CarPlay, la radio et les autres applis restent intactes.<br><br>' +
        '<b>1.</b> Choisis l\'écran d\'accueil d\'origine de l\'autoradio (souvent « Launcher3 »).<br><b>2.</b> Pour supprimer ce lanceur, reviens ici et touche « Désinstaller ». ' +
        'Les données du lanceur (réglages) seront effacées.</div>' +
        '<div class="sheet-actions"><button class="sbtn press" data-l="home" style="background:rgba(255,255,255,.18)">1. Écran d\'accueil</button><button class="sbtn danger press" data-l="uninstall">2. Désinstaller</button></div>', function (sh) {
        $$('[data-l]', sh).forEach(function (b) { b.onclick = function () { closeSheet(); Bridge.openSystem(b.getAttribute('data-l')); }; });
      });
    }
    else if (a === 'access') askAccess();
    else if (p[0] === 'sys') Bridge.openSystem(p[1]);
    else if (a === 'wall') wallSheet();
    else if (a === 'theme') { var th = store.get('theme', 'auto'); th = th === 'auto' ? 'dark' : th === 'dark' ? 'light' : 'auto'; store.set('theme', th); applyTheme(); renderSettings(); }
    else if (p[0] === 'role') roleSheet(p[1], $('.grow', el).textContent);
    else if (a === 'autoread') { var ar = store.get('autoread', 'boot'); ar = ar === 'off' ? 'boot' : ar === 'boot' ? '15' : 'off'; store.set('autoread', ar); renderSettings(); }
    else if (a === 'zoom') { var z = store.get('zoom', 'grand'); z = z === 'normal' ? 'grand' : z === 'grand' ? 'xl' : 'normal'; store.set('zoom', z); fit(); renderApps(); renderSettings(); alignGlass(); setTimeout(refitFrames, 400); }
    else if (a === 'layout') layoutSheet();
    else if (a === 'appsrows') { store.set('appsRows', store.get('appsRows', 2) === 2 ? 3 : 2); appsPageIdx = 0; fit(); renderApps(); renderSettings(); alignGlass(); }
    else if (a === 'custom') showPage('custom', el);
    else if (a === 'canapp') canAppSheet(false);
    else if (a === 'setup') setupSheet();
    else if (a === 'can:logs') { openSheet('<div class="t-headline">Ordinateur de bord en direct</div><div class="t-sub" style="-webkit-user-select:text;user-select:text">' +
      (Bridge.canLive() ? '<b>Actif</b> : carburant, batterie, température, kilométrage et régime arrivent en direct, CarCan n\'est plus ouvert.' :
       Bridge.canLogs() ? 'Autorisé, en attente des premières données du boîtier CAN (moteur allumé, CarCan installé).' :
       'Une seule fois, depuis un ordinateur relié en USB (débogage USB activé) :<br><br><b>adb shell pm grant fr.ibiza.launcher android.permission.READ_LOGS</b><br><br>puis redémarre l\'autoradio. Le lanceur lira alors les données du CAN en direct, sans ouvrir CarCan.') +
      '</div><div class="sheet-actions">' + (Bridge.canLogs() ? '' : '<button class="sbtn wide press" data-r="1">Essayer l\'autorisation automatique (root)</button>') + '<button class="sbtn wide press" data-x="1">OK</button></div>', function (sh) {
        $('[data-x]', sh).onclick = closeSheet;
        var rb = $('[data-r]', sh); if (rb) rb.onclick = function () { closeSheet(); toast('Essai en cours… accepte la fenêtre « root » si elle apparaît'); Bridge.tryRoot(); };
      }); }
    else if (a === 'icons:reload') { Bridge.reloadIcons(); toast('Icônes rechargées'); }
    else if (a === 'icons:list') {
      var lf = Bridge.appList();
      if (!lf) { toast('Écriture de la liste impossible'); return; }
      openSheet('<div class="t-headline">Icônes perso</div><div class="t-sub" style="-webkit-user-select:text;user-select:text">' +
        'La liste de tes applis, avec le nom de fichier de chaque icône, est dans :<br><b>' + esc(lf.replace(/^.*\/Android\//, 'Android/')) + '</b><br><br>' +
        'Mets tes images (PNG carré, 192 × 192 px ou plus) dans ce même dossier avec ces noms, puis touche « Recharger les icônes perso ». ' +
        'Elles s\'affichent en pleine tuile.</div><div class="sheet-actions"><button class="sbtn wide press" data-ok="1">OK</button></div>', function (s) {
        tappable($('[data-ok]', s), closeSheet);
      });
    }
    else if (a === 'glass') { var m = store.get('glass', 'sim'); m = m === 'sim' ? 'real' : m === 'real' ? 'off' : 'sim'; store.set('glass', m); applyGlassMode(); renderSettings(); }
    else if (p[0] === 'toggle') { var dflt = p[1] !== 'lite'; var v = !store.get(p[1], dflt); store.set(p[1], v); $('.switch', el).classList.toggle('on', v); if (p[1] === 'lite') applyLite(); }
    else if (a === 'test:ready') { showPage('home'); setTimeout(function () { showReady(true); }, 350); }
    else if (a === 'diag:export') { var f = Bridge.diagExport(); toast(f ? 'Enregistré : ' + f : 'Export impossible'); }
    else if (a === 'diag:clear') { Bridge.diagClear(); renderSettings(); }
  }
  tappable($('#card-clock'), function () {}, function () { showPage('settings', $('#card-clock')); });

  /* ======================= démarrage ======================= */
  function boot() {
    fit(); applyLite(); applyLayout(false); setTimeout(function () { fitTexts(true); }, 300);
    applyGlassMode(); applyTheme();
    loadApps(); renderDock(); renderQuick(); renderApps();
    $('#btn-pages').innerHTML = svg('grid');
    $('#st-bt').innerHTML = svg('bt'); $('#st-wifi').innerHTML = svg('wifi');
    var st = Bridge.state();
    renderMedia(st.media); renderCd();
    tick(); setInterval(function () { tick(); applyTheme(); applyWall(); }, 1000 * 5);
    $('#wall-file').addEventListener('change', function (e) { var f = e.target.files && e.target.files[0]; if (f) loadCustomWall(f); e.target.value = ''; });
    alignGlass();
    Object.keys(pageSprings).forEach(function () {});
    setTimeout(introSpin, 250);
  }
  /* données véhicule (CAN) : huile, eau, extérieur, batterie */
  function setCd(id, v, unit, warnIf) {
    var el = $(id); if (!el) return;
    if (v == null || v === '' || isNaN(v)) { el.textContent = '—'; el.classList.remove('warn'); return; }
    el.textContent = (unit === 'V' ? Number(v).toFixed(1).replace('.', ',') : Math.round(v)) + (unit === 'V' ? ' V' : '°');
    el.classList.toggle('warn', !!(warnIf && warnIf(v)));
  }

  /* ======================= v1.13 : écran « Prêt à partir » (plein écran) =======================
     Au démarrage de l'autoradio (et au réveil après plus de 15 min de veille), l'écran s'affiche tout de suite en
     « lecture… » (aucune valeur périmée), puis la lecture CarCan se fait sous le rideau : c'est cet écran qu'on voit
     pendant la lecture, jamais CarCan. Les vraies valeurs s'affichent au retour ; « C'est parti » ramène à l'accueil. */
  var RD = { tick: Date.now(), state: 'off', mv: 0, t: null, wait: null };
  function washerLow(w) { return !!w && !/^\s*(normal|ok|plein|full|bon)\s*$/i.test(w) && /anormal|bas|faible|low|insuf|vide|empty|manque|ajout|rempli|add|niveau/i.test(w); }
  function readyAlerts() {
    var a = [], c = car || {};
    if (c.battery != null && c.battery < 12) a.push({ lv: 2, ic: 'battery', t: 'Batterie faible', s: fmtN(c.battery, 1) + ' V : à faire contrôler' });
    if (washerLow(c.washer)) a.push({ lv: 1, ic: 'gauge', t: 'Lave-glace à remplir', s: String(c.washer) });
    if (c.outside != null && c.outside <= 3) a.push({ lv: 1, ic: 'temp', t: 'Risque de verglas', s: fmtN(c.outside, 1) + ' °C dehors : prudence' });
    if ((c.range != null && c.range < 60) || (c.fuel != null && c.fuel < 7)) a.push({ lv: 1, ic: 'fuel', t: 'Réserve de carburant', s: c.range != null ? 'Autonomie ' + fmtN(c.range) + ' km' : fmtN(c.fuel) + ' L restants' });
    a.sort(function (x, y) { return y.lv - x.lv; });
    return a;
  }
  function readyRender() {
    var el = $('#ready'), c = car || {}, now = new Date(), h = now.getHours(), loading = RD.state === 'loading';
    var hello = h >= 5 && h < 12 ? 'Bonjour' : h >= 12 && h < 18 ? 'Bon après-midi' : 'Bonsoir';
    var days = ['dimanche', 'lundi', 'mardi', 'mercredi', 'jeudi', 'vendredi', 'samedi'], months = ['janvier', 'février', 'mars', 'avril', 'mai', 'juin', 'juillet', 'août', 'septembre', 'octobre', 'novembre', 'décembre'];
    var tile = function (ic, label, val, warn) { return '<div class="rdf-tile' + (warn ? ' warn' : '') + '">' + svg(ic) + '<span>' + label + '</span><b>' + (loading ? '<i class="sk"></i>' : val) + '</b></div>'; };
    var lowF = (c.range != null && c.range < 60) || (c.fuel != null && c.fuel < 7);
    var tiles = tile('fuel', c.range != null || loading ? 'Autonomie' : 'Carburant', c.range != null ? fmtN(c.range) + ' km' : c.fuel != null ? fmtN(c.fuel) + ' L' : '—', !loading && lowF) +
      tile('temp', 'Extérieur', c.outside != null ? fmtN(c.outside, 1) + ' °C' : '—', !loading && c.outside != null && c.outside <= 3) +
      tile('battery', 'Batterie', c.battery != null ? fmtN(c.battery, 1) + ' V' : '—', !loading && c.battery != null && c.battery < 12) +
      tile('car', 'Kilométrage', c.odo != null ? fmtN(Math.round(c.odo)) + ' km' : '—', false);
    var body;
    if (loading) body = '<div class="rdf-load"><i class="spin"></i>Lecture des données du véhicule…</div>';
    else {
      var al = readyAlerts();
      body = !al.length ? '<div class="rdf-ok">' + svg('check') + '<div><b>Tout est en ordre</b><span>Bonne route !</span></div></div>'
        : '<div class="rdf-list">' + al.slice(0, 4).map(function (x) { return '<div class="rdf-al lv' + x.lv + '">' + svg(x.ic) + '<div><b>' + esc(x.t) + '</b><span>' + esc(x.s) + '</span></div></div>'; }).join('') + '</div>' +
          (al.length > 4 ? '<div class="rdf-more">+ ' + esc(al.slice(4).map(function (x) { return x.t; }).join(', ')) + '</div>' : '');
      if (RD.state === 'stale') body += '<div class="rdf-note">Lecture de l\'ordinateur de bord impossible pour l\'instant : dernières valeurs connues' + (car.at ? ' (' + frDate(new Date(car.at)) + ')' : '') + '.</div>';
    }
    el.innerHTML = '<div class="rdf-glow"></div><div class="rdf-in">' +
      '<div class="rdf-head"><div><div class="rdf-hello">' + hello + '</div><div class="rdf-sub">Prêt à partir · ' + days[now.getDay()] + ' ' + now.getDate() + ' ' + months[now.getMonth()] + (!loading && c.odo != null ? ' · ' + fmtN(Math.round(c.odo)) + ' km' : '') + '</div></div>' +
      '<div class="rdf-time">' + pad(h) + ':' + pad(now.getMinutes()) + '</div></div>' +
      '<div class="rdf-tiles">' + tiles + '</div><div class="rdf-body">' + body + '</div>' +
      '<button class="rdf-go press" id="rdf-go">C\'est parti</button></div>';
    $('#rdf-go').onclick = hideReady;
  }
  function readyOpen() { return RD.state !== 'off'; }
  function showReady(force) {
    if (!force && (!store.get('ready', true) || (!Bridge.mock && !store.get('setupDone', false)))) return false;
    var canRead = !Bridge.mock && Bridge.canRefreshPossible() && store.get('autoread', 'boot') !== 'off';
    if (current !== 'home') showPage('home');
    if ($('#sheet-scrim').classList.contains('on')) closeSheet();
    RD.state = canRead ? 'loading' : (Bridge.mock ? 'fresh' : 'stale'); RD.mv = 0;
    readyRender();
    var el = $('#ready'); el.classList.add('on'); el.setAttribute('aria-hidden', 'false');
    clearTimeout(RD.wait); clearTimeout(RD.t);
    if (canRead) {
      // la lecture CarCan démarre une fois l'écran affiché : le rideau en fait une image figée, CarCan n'apparaît jamais
      setTimeout(readyRead, Bridge.canLive() ? 300 : RD.boot ? 5000 : 1500);   // v1.15 : données déjà en direct -> immédiat
    }
    RD.boot = false;
    RD.t = setTimeout(function () { if (readyOpen()) hideReady(); }, 5 * 60000);
    return true;
  }
  function readyRead() {          // jamais par-dessus CarPlay ou une autre appli : on attend que le lanceur soit affiché
    if (RD.state !== 'loading') return;
    if (!visible) { RD.pending = true; return; }
    RD.pending = false; lastAutoRead = Date.now(); Bridge.canRefresh();
    clearTimeout(RD.wait); RD.wait = setTimeout(function () { if (RD.state === 'loading') { RD.state = 'stale'; readyRender(); } }, 12000);
  }
  function hideReady() {
    if (!readyOpen()) return;
    RD.state = 'off'; clearTimeout(RD.wait); clearTimeout(RD.t);
    var el = $('#ready'); el.classList.remove('on'); el.setAttribute('aria-hidden', 'true');
    if (current !== 'home') showPage('home');
    renderCd();
  }
  Bridge.on('car', function (d) {          // valeurs fraîches : l'écran passe de « lecture… » aux vraies valeurs
    if (!readyOpen() || !d || Object.keys(d).length < 2) return;
    RD.state = 'fresh'; clearTimeout(RD.wait);
    setTimeout(function () { readyRender(); $('#ready').classList.add('pop'); setTimeout(function () { $('#ready').classList.remove('pop'); }, 500); }, 30);
  });
  Bridge.on('resume', function (d) {        // retour de la lecture masquée sans valeurs : on montre les dernières connues
    if (d && d.silent && RD.state === 'loading') setTimeout(function () { if (RD.state === 'loading') { RD.state = 'stale'; readyRender(); } }, 2500);
    else if (!(d && d.silent) && RD.pending) setTimeout(readyRead, 1200);
  });
  Bridge.on('speed', function (d) {          // on roule depuis 3 s : l'écran s'efface
    var k = d && d.kmh ? d.kmh : 0;
    if (!readyOpen()) return;
    if (k >= 10) { if (!RD.mv) RD.mv = Date.now(); else if (Date.now() - RD.mv > 3000) hideReady(); } else RD.mv = 0;
  });
  RD.boot = true;
  setTimeout(function () { if (!showReady(false)) bootRead = true; }, 300);
  if (!Bridge.mock && !store.get('setupDone', false)) setTimeout(function () { if (!$('#sheet-scrim').classList.contains('on')) setupSheet(); }, 1500);   // v1.26 : première installation      // démarrage de l'autoradio
  setInterval(function () {                                                          // réveil après une veille
    var now = Date.now();
    if (now - RD.tick > 15 * 60000) setTimeout(function () { showReady(false); }, 800);
    RD.tick = now;
  }, 20000);

  /* carte horloge : les 4 premières données disponibles (selon ce que le boîtier CAN fournit) */
  var CD = [
    ['outside', 'Ext.', function (v) { return fmtN(v, 1) + '°'; }, function (v) { return v <= 3; }],
    ['coolant', 'Eau', function (v) { return fmtN(v) + '°'; }, function (v) { return v > 110; }],
    ['oil', 'Huile', function (v) { return fmtN(v) + '°'; }, function (v) { return v > 130; }],
    ['battery', 'Batt.', function (v) { return fmtN(v, 1) + ' V'; }, function (v) { return v < 11.8; }],
    ['fuel', 'Carbu.', function (v) { return fmtN(v) + ' L'; }, function (v) { return v < 7; }],
    ['range', 'Auton.', function (v) { return fmtN(v) + ' km'; }, function (v) { return v < 60; }],
    ['rpm', 'Régime', function (v) { return fmtN(v); }, null],
    ['odo', 'Km', function (v) { return fmtN(v); }, null]
  ];
  function renderCd() {
    var have = CD.filter(function (c) { return car[c[0]] != null; });
    var rest = CD.filter(function (c) { return car[c[0]] == null && ['outside', 'battery', 'fuel', 'rpm'].indexOf(c[0]) >= 0; });
    var pick = have.concat(rest).slice(0, 4);
    pick.forEach(function (c, i) {
      var l = $('#cdl-' + i), b = $('#cd-' + i); if (!l || !b) return;
      l.textContent = c[1];
      var v = car[c[0]];
      b.textContent = v == null ? '—' : c[2](v);
      b.classList.toggle('warn', v != null && !!(c[3] && c[3](v)));
    });
  }
  Bridge.on('car', function (d) {
    d = d || {};
    Object.keys(d).forEach(function (k) { car[k] = d[k]; }); if (!car.at) car.at = Date.now();
    store.set('car', car);
    d = car;
    if (current === 'vehicle') renderTrip();
    renderCd();
  });
  var stopT;
  Bridge.on('speed', function (d) {
    var k = d && d.kmh ? d.kmh : 0, card = $('#card-clock');
    $('#c-kmh').textContent = k;
    if (k >= 4) { clearTimeout(stopT); card.classList.add('moving'); }
    else { clearTimeout(stopT); stopT = setTimeout(function () { card.classList.remove('moving'); }, 4000); }
  });
  /* lecture automatique de CarCan : ~8 s après le démarrage, puis toutes les 15 min si on est sur l'accueil
     (jamais par-dessus CarPlay ou une autre appli). v1.10 : CarCan s'ouvre sous un rideau (image figée du lanceur), on ne le voit plus. */
  var visible = true, lastAutoRead = 0, bootRead = false;
  Bridge.on('pause', function () { visible = false; });
  Bridge.on('resume', function () { visible = true; });
  function autoRead(force) {
    var mode = store.get('autoread', 'boot');
    if (mode === 'off' || Bridge.mock || !Bridge.canRefreshPossible()) return;
    if (!visible || current !== 'home' || $('#sheet-scrim').classList.contains('on')) return;
    if (!force && (mode !== '15' || Date.now() - lastAutoRead < 15 * 60000)) return;
    lastAutoRead = Date.now(); Bridge.canRefresh();
  }
  setTimeout(function () { if (bootRead) autoRead(true); }, 8000);   // sinon c'est l'écran « Prêt à partir » qui lance la lecture
  setInterval(function () { autoRead(false); }, 60000);
  Bridge.on('turn', function (t) { var el = $('#turn'); el.classList.toggle('l', !!(t && t.left)); el.classList.toggle('r', !!(t && t.right)); });
  Bridge.on('apps', function () { loadApps(); renderDock(); renderQuick(); renderApps(); alignGlass(); });
  Bridge.on('status', function (s) { $('#st-bt').classList.toggle('on', !!s.bt); $('#st-wifi').classList.toggle('on', !!s.wifi); });
  Bridge.on('resume', function (d) { if (d && d.silent) return; if (current !== 'home') showPage('home'); introSpin(); });   // retour de la lecture CarCan masquée : on reste où l'on était
  Bridge.on('home', function () { if (current !== 'home') showPage('home'); else introSpin(); });
  window.addEventListener('resize', function () { fit(); renderApps(); alignGlass(); setTimeout(refitFrames, 400); fitTexts(true); });
  (function () {
    // seuls les changements qui touchent un texte ajustable relancent l'ajustement (pas la barre de progression, ni les boutons)
    var mo = new MutationObserver(function (recs) {
      for (var i = 0; i < recs.length; i++) {
        var t = recs[i].target; if (t && t.nodeType === 3) t = t.parentNode;
        if (t && t.closest && t.closest(FIT_WATCH)) { fitTexts(); return; }
      }
    });
    ['#page-home', '#apps-track'].forEach(function (sel) { var el = $(sel); if (el) mo.observe(el, { childList: true, characterData: true, subtree: true }); });
    var lastClass = root.className;
    new MutationObserver(function () { if (root.className !== lastClass) { lastClass = root.className; fitTexts(true); } }).observe(root, { attributes: true, attributeFilter: ['class'] });
  })();
  boot();
  /* v1.19 : signe de vie pour le chien de garde Android, cadencé par l'affichage (s'arrête si l'écran se fige) */
  (function () {
    if (!window.Native || typeof window.Native.alive !== 'function') return;
    // v1.22 : plus aucune minuterie ici : c'est Android qui interroge la page (au retour sur le lanceur, puis toutes les 5 min)
  })();
})();
