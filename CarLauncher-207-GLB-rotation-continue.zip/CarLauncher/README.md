# Car Launcher — Peugeot 207

Lanceur Android pour l'écran de la 207 (version allégée du Car Launcher 1.27.1).

## Ce qu'il contient
- Accueil avec la **207 en 3D** (48 vues pré-rendues interpolées par WebGL, rotation automatique en continu, on la fait aussi tourner au doigt), musique, radio, applis, horloge.
- **Compteur de vitesse** (lu sur le CAN, sinon sur le GPS), température extérieure, eau, huile, batterie.
- Page **Véhicule** = ordinateur de bord (autonomie, consommation, carburant, kilométrage…), lu sur l'appli CAN de l'autoradio.
- **Personnaliser** : fond d'écran, couleur de l'interface, thème, icônes perso.

## Ce qui a été retiré
Entretien (carnet, révision, vidange, PDF), radars de recul, détection et animation des portes, alertes
« ouvrant ouvert en roulant », fenêtre flottante, packs voiture, assistant d'apprentissage des portes,
exports QR / rapports, outils de rendu, documentation et historique des versions.

## Construire l'APK
Ouvrir le dossier dans Android Studio, puis Build > Build APK (ou `./gradlew assembleDebug`).
Même identifiant d'appli que l'ancienne version (`fr.ibiza.launcher`) : elle se met à jour par-dessus.

## Changer les images de la voiture
Les vues sont dans `app/src/main/assets/www/img/car/` : `hero_00.webp` … `hero_47.webp` (une tous les 7,5°, la vue 8 = 3/4
avant droit), `floor.webp` (le plateau) et `flow_00.png` … `flow_47.png` (champs de mouvement entre deux vues voisines,
utilisés par WebGL pour interpoler la rotation). `www/js/config.js` donne le nombre de vues (`frames`), la vue de départ
(`homeView`) et l'amplitude des flux (`flowMax`). Si tu remplaces les vues, il faut régénérer les flux avec elles ;
sans fichiers de flux ou sans WebGL, l'application retombe sur un simple fondu enchaîné.

## Crédits
Modèle 3D « Peugeot 207 » par **romanian_guy_0069** (https://sketchfab.com/3d-models/peugeot-207-3d849c22f2914013a183484a57fa71ba),
licence **CC BY 4.0** (https://creativecommons.org/licenses/by/4.0/). Modifications : version argent du modèle,
rendue en images 2D (48 vues + plateau + champs de mouvement). Cette mention doit rester si tu partages l'application.


## Rendu 3D GLB direct (version Peugeot 207)
- Le modèle `app/src/main/assets/www/models/peugeot_207.glb` est chargé directement dans la vue d'accueil avec Three.js / GLTFLoader.
- Three.js est copié dans les assets lors de la compilation depuis Maven Central ; l'application n'utilise aucun CDN ni Internet à l'exécution.
- L'angle est piloté par l'animation continue existante du lanceur. La rotation est cyclique et ne se bloque pas à 360°.
- La compilation nécessite Internet pour récupérer la dépendance Three.js la première fois ; l'APK final fonctionne hors ligne.
