import * as THREE from 'three';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';

(() => {
  const host = document.getElementById('tt-3d');
  if (!host) return;
  const scene = new THREE.Scene();
  const camera = new THREE.PerspectiveCamera(32, 1, 0.01, 1000);
  const renderer = new THREE.WebGLRenderer({ alpha: true, antialias: true, powerPreference: 'low-power' });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.5));
  renderer.setClearColor(0x000000, 0);
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = 1.05;
  host.appendChild(renderer.domElement);

  scene.add(new THREE.HemisphereLight(0xffffff, 0x606070, 2.0));
  const key = new THREE.DirectionalLight(0xffffff, 2.2);
  key.position.set(4, 7, 6); scene.add(key);
  const fill = new THREE.DirectionalLight(0xdde8ff, 1.0);
  fill.position.set(-5, 3, -4); scene.add(fill);
  const rim = new THREE.DirectionalLight(0xffffff, 1.2);
  rim.position.set(0, 5, -7); scene.add(rim);

  const pivot = new THREE.Group();
  scene.add(pivot);
  let model = null, ready = false, currentAngle = 0;
  function resize() {
    const w = Math.max(1, host.clientWidth), h = Math.max(1, host.clientHeight);
    renderer.setSize(w, h, false);
    camera.aspect = w / h;
    camera.updateProjectionMatrix();
  }
  const ro = new ResizeObserver(resize); ro.observe(host); resize();

  window.setCarAngle = function(deg) {
    currentAngle = Number(deg) || 0;
    if (ready) pivot.rotation.y = THREE.MathUtils.degToRad(currentAngle);
  };

  const loader = new GLTFLoader();
  loader.load('models/peugeot_207.glb', (gltf) => {
    model = gltf.scene;
    model.traverse((o) => {
      if (o.isMesh) {
        o.frustumCulled = true;
        if (o.material) {
          o.material.side = THREE.FrontSide;
          o.material.needsUpdate = true;
        }
      }
    });
    const box = new THREE.Box3().setFromObject(model);
    const center = box.getCenter(new THREE.Vector3());
    const size = box.getSize(new THREE.Vector3());
    model.position.sub(center);
    pivot.add(model);
    const maxDim = Math.max(size.x, size.y, size.z);
    const distance = maxDim / (2 * Math.tan(THREE.MathUtils.degToRad(camera.fov * 0.5))) * 1.22;
    camera.position.set(distance * 1.05, distance * 0.52, distance * 1.45);
    camera.lookAt(0, 0, 0);
    ready = true;
    pivot.rotation.y = THREE.MathUtils.degToRad(currentAngle);
    host.classList.add('glb-ready');
  }, undefined, (err) => {
    console.error('Impossible de charger le modèle GLB Peugeot 207', err);
    host.classList.add('glb-error');
  });

  let last = 0;
  function frame(t) {
    requestAnimationFrame(frame);
    // Render only while the host is visible; the rotation angle is driven by app.js.
    if (!host.isConnected || !host.clientWidth || !host.clientHeight) return;
    if (ready) renderer.render(scene, camera);
    last = t;
  }
  requestAnimationFrame(frame);
})();
