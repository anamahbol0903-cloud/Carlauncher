window.IBZ_CONFIG={"frames": 48, "homeView": 8, "flowMax": 40, "car": {"name": "207", "model": "Peugeot 207"}};
