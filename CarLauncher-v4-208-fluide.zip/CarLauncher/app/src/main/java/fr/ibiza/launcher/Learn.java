package fr.ibiza.launcher;

import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.provider.Settings;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.TreeMap;

/**
 * Mode apprentissage : l'utilisateur fait une action dans la voiture (feux, porte, coffre…).
 * Le lanceur lit l'état du poste juste avant et juste après (réglages Android, propriétés système) et note les
 * événements d'accessibilité reçus entre-temps (fenêtres de com.clw.vehicleinfos…). La différence montre
 * quelle information change quand l'action a lieu ; l'interface en déduit, par exemple, la clé des feux.
 */
final class Learn {
    private static boolean active = false;
    private static Map<String, String> before = null;
    private static final Map<String, Integer> events = new LinkedHashMap<String, Integer>();

    private Learn() {}

    /** appelé par le service d'accessibilité pour chaque événement d'une autre appli */
    static synchronized void event(String pkg, String cls) {
        if (!active || pkg == null) return;
        String k = pkg + " / " + cls;
        Integer n = events.get(k);
        events.put(k, n == null ? 1 : n + 1);
    }

    static synchronized String begin(Context c) {
        events.clear();
        before = snapshot(c);
        active = true;
        Hub.log("APPRENTISSAGE début (" + before.size() + " valeurs lues)");
        return "{\"ok\":true,\"n\":" + before.size() + "}";
    }

    static synchronized String end(Context c) {
        active = false;
        JSONObject out = new JSONObject();
        try {
            Map<String, String> after = snapshot(c);
            JSONArray ch = new JSONArray();
            if (before != null) {
                for (Map.Entry<String, String> e : after.entrySet()) {
                    String k = e.getKey();
                    String a = before.get(k);
                    String b = e.getValue();
                    boolean same = (a == null) ? (b == null) : a.equals(b);
                    if (same || noise(k)) continue;
                    JSONObject o = new JSONObject();
                    o.put("k", k);
                    o.put("from", a == null ? "" : cut(a));
                    o.put("to", b == null ? "" : cut(b));
                    ch.put(o);
                    if (ch.length() >= 60) break;
                }
            }
            out.put("changes", ch);
            JSONArray ev = new JSONArray();
            for (Map.Entry<String, Integer> e : events.entrySet()) {
                if (ev.length() >= 25) break;
                ev.put(e.getKey() + " ×" + e.getValue());
            }
            out.put("events", ev);
        } catch (Exception ignored) {}
        before = null;
        Hub.log("APPRENTISSAGE fin : " + out);
        return out.toString();
    }

    private static String cut(String s) { return s.length() > 80 ? s.substring(0, 80) : s; }

    /** bruit connu : valeurs qui bougent toutes seules ou qui suivent simplement la luminosité de l'écran */
    private static boolean noise(String k) {
        String l = k.toLowerCase();
        return l.contains("screen_brightness") || l.contains("bluetooth_") || l.contains("next_alarm") || l.contains("uptime")
                || l.contains("elapsed") || l.contains("debug.tracing") || l.contains("gsm.") || l.contains("dhcp") || l.contains("init.svc")
                || l.contains("wifi") || l.contains("net.") || l.contains("time") || l.contains("date");
    }

    private static Map<String, String> snapshot(Context c) {
        Map<String, String> m = new TreeMap<String, String>();
        readSettings(c, Settings.System.CONTENT_URI, "system", m);
        readSettings(c, Settings.Global.CONTENT_URI, "global", m);
        readSettings(c, Settings.Secure.CONTENT_URI, "secure", m);
        readProps(m);
        return m;
    }

    private static void readSettings(Context c, Uri uri, String ns, Map<String, String> m) {
        Cursor cur = null;
        try {
            cur = c.getContentResolver().query(uri, new String[] { "name", "value" }, null, null, null);
            if (cur == null) return;
            while (cur.moveToNext()) {
                String k = cur.getString(0);
                if (k != null) m.put(ns + "/" + k, cur.getString(1));
            }
        } catch (Exception ignored) {
        } finally {
            if (cur != null) { try { cur.close(); } catch (Exception ignored) {} }
        }
    }

    private static void readProps(Map<String, String> m) {
        BufferedReader r = null;
        try {
            Process p = Runtime.getRuntime().exec("getprop");
            r = new BufferedReader(new InputStreamReader(p.getInputStream(), "UTF-8"));
            String line;
            while ((line = r.readLine()) != null) {
                int a = line.indexOf("]: [");
                if (!line.startsWith("[") || a < 0 || !line.endsWith("]")) continue;
                m.put("prop/" + line.substring(1, a), line.substring(a + 4, line.length() - 1));
            }
        } catch (Exception ignored) {
        } finally {
            if (r != null) { try { r.close(); } catch (Exception ignored) {} }
        }
    }
}
