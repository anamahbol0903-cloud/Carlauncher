window.IBZ_CONFIG={"frames": 96, "homeView": 16, "flowMax": 32, "car": {"name": "207", "model": "Peugeot 207"}};
