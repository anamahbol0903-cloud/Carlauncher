package fr.ibiza.launcher;

import android.content.Context;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;

import java.io.IOException;
import java.net.Socket;

/** Réglages et démarrage de la lecture OBD2 Wi-Fi (température du moteur, tension de batterie). */
final class ObdCtl {
    private ObdCtl() {}
    static final String DEF_HOST = "192.168.0.10";
    static final int DEF_PORT = 35000;

    private static SharedPreferences prefs(Context c) { return c.getApplicationContext().getSharedPreferences("ibz", Context.MODE_PRIVATE); }
    static String host(Context c) { String h = prefs(c).getString("obd_host", DEF_HOST); return h == null || h.trim().isEmpty() ? DEF_HOST : h.trim(); }
    static int port(Context c) { try { int p = Integer.parseInt(prefs(c).getString("obd_port", "" + DEF_PORT)); return p > 0 && p < 65536 ? p : DEF_PORT; } catch (Exception e) { return DEF_PORT; } }
    static boolean on(Context c) { return "true".equals(prefs(c).getString("obd_on", "false")); }

    static void autostart(Context c) { if (on(c)) restart(c); }

    static void set(Context c, String host, int port, boolean on) {
        prefs(c).edit().putString("obd_host", host == null ? DEF_HOST : host.trim()).putString("obd_port", "" + port).putString("obd_on", on ? "true" : "false").apply();
        restart(c);
    }

    static void restart(Context c) {
        final Context app = c.getApplicationContext();
        Obd.stop();
        if (!on(app)) return;
        Obd.start(host(app), port(app), new Obd.Maker() {
            @Override public Socket make() throws IOException { return wifiSocket(app); }
        }, new Obd.Sink() {
            @Override public void data(String json) { Hub.emit("car", json); }
            @Override public void log(String line) { Hub.log("OBD2 Wi-Fi : " + line); }
        });
    }

    /** Socket forcé sur le Wi-Fi : sans internet sur l'adaptateur, Android enverrait sinon le trafic ailleurs. */
    private static Socket wifiSocket(Context c) throws IOException {
        try {
            ConnectivityManager cm = (ConnectivityManager) c.getSystemService(Context.CONNECTIVITY_SERVICE);
            if (cm != null) {
                for (Network n : cm.getAllNetworks()) {
                    NetworkCapabilities nc = cm.getNetworkCapabilities(n);
                    if (nc != null && nc.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) return n.getSocketFactory().createSocket();
                }
            }
        } catch (Exception ignored) {}
        return new Socket();
    }
}
