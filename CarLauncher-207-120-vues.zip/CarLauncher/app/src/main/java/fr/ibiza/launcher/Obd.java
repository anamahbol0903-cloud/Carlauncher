package fr.ibiza.launcher;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Lecture OBD2 par adaptateur Wi-Fi ELM327 (comme l'appli Torque) : température du liquide de refroidissement
 * et tension de la batterie. Classe sans dépendance Android : elle se teste sur un ordinateur.
 */
final class Obd {
    interface Sink { void data(String json); void log(String line); }
    interface Maker { Socket make() throws IOException; }

    private static volatile int gen = 0;
    private static volatile String state = "off";   // off | connecting | ok | err
    private static final Pattern VOLT = Pattern.compile("(\\d{1,2}(?:\\.\\d{1,2})?)\\s*V", Pattern.CASE_INSENSITIVE);

    static String state() { return state; }
    static synchronized void stop() { gen++; state = "off"; }

    static synchronized void start(final String host, final int port, final Maker maker, final Sink sink) {
        final int my = ++gen;
        state = "connecting";
        Thread t = new Thread(new Runnable() { public void run() { loop(my, host, port, maker, sink); } }, "obd-wifi");
        t.setDaemon(true);
        t.start();
    }

    private static boolean alive(int my) { return my == gen; }

    private static void nap(int my, long ms) {
        long end = System.currentTimeMillis() + ms;
        while (alive(my) && System.currentTimeMillis() < end) {
            try { Thread.sleep(100); } catch (InterruptedException e) { return; }
        }
    }

    /** Envoie une commande et lit la réponse jusqu'au « > » de l'ELM327. */
    static String ask(OutputStream out, InputStream in, String cmd) throws IOException {
        out.write((cmd + "\r").getBytes("US-ASCII"));
        out.flush();
        StringBuilder sb = new StringBuilder();
        while (true) {
            int c = in.read();
            if (c < 0) throw new IOException("connexion fermée");
            if (c == '>') break;
            if (sb.length() < 400) sb.append((char) c);
        }
        return sb.toString().replace('\r', ' ').replace('\n', ' ').trim();
    }

    /** Octets de données qui suivent le préfixe de réponse (ex. « 4105 »), ou null. */
    static int[] hex(String reply, String prefix) {
        String t = reply.replace(" ", "").toUpperCase(Locale.US);
        int i = t.indexOf(prefix);
        if (i < 0) return null;
        t = t.substring(i + prefix.length());
        int n = t.length() / 2;
        int[] b = new int[n];
        for (int k = 0; k < n; k++) {
            try { b[k] = Integer.parseInt(t.substring(2 * k, 2 * k + 2), 16); } catch (NumberFormatException e) { return null; }
        }
        return n > 0 ? b : null;
    }

    static Double voltage(String reply) {
        Matcher m = VOLT.matcher(reply);
        if (!m.find()) return null;
        try { double v = Double.parseDouble(m.group(1)); return v >= 4 && v <= 32 ? Double.valueOf(v) : null; } catch (NumberFormatException e) { return null; }
    }

    private static void loop(int my, String host, int port, Maker maker, Sink sink) {
        while (alive(my)) {
            Socket s = null;
            try {
                s = maker.make();
                s.connect(new InetSocketAddress(host, port), 4000);
                s.setSoTimeout(5000);
                OutputStream out = s.getOutputStream();
                InputStream in = s.getInputStream();
                for (String c : new String[] { "ATZ", "ATE0", "ATL0", "ATS0", "ATH0" }) ask(out, in, c);
                sink.log("connecté à " + host + ":" + port);
                Double lastBat = null; Integer lastCool = null; long lastEmit = 0;
                while (alive(my)) {
                    Double bat = voltage(ask(out, in, "ATRV"));
                    Integer cool = null;
                    int[] b = hex(ask(out, in, "0105"), "4105");
                    if (b != null && b[0] - 40 >= -40 && b[0] - 40 <= 150) cool = Integer.valueOf(b[0] - 40);
                    if (bat == null) {
                        int[] v = hex(ask(out, in, "0142"), "4142");
                        if (v != null && v.length >= 2) bat = Double.valueOf((v[0] * 256 + v[1]) / 1000.0);
                    }
                    if (bat != null || cool != null) {
                        state = "ok";
                        long now = System.currentTimeMillis();
                        boolean changed = (bat != null && (lastBat == null || Math.abs(bat - lastBat) >= 0.1))
                                || (cool != null && !cool.equals(lastCool));
                        if (changed || now - lastEmit > 10000) {
                            StringBuilder j = new StringBuilder("{");
                            if (bat != null) j.append("\"battery\":").append(String.format(Locale.US, "%.1f", bat));
                            if (cool != null) j.append(bat != null ? "," : "").append("\"coolant\":").append(cool);
                            j.append("}");
                            sink.data(j.toString());
                            if (bat != null) lastBat = bat;
                            if (cool != null) lastCool = cool;
                            lastEmit = now;
                        }
                    } else {
                        state = "err";   // adaptateur joint mais aucune réponse utile (contact coupé ?)
                    }
                    nap(my, 1500);
                }
            } catch (Exception e) {
                if (alive(my)) { state = "err"; sink.log("erreur : " + e); }
            } finally {
                if (s != null) { try { s.close(); } catch (IOException ignored) {} }
            }
            nap(my, 4000);
        }
    }
}
